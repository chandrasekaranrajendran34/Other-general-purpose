# Phase 2 - Basic Working Agent

This phase implements a dependency-free Python baseline for the Inventory Operations Copilot.

The baseline deliberately uses simple rules and templates. It does not use LangChain, an LLM, retrieval, embeddings, external APIs, or write-capable tools. This provides a measurable starting point for later phases.

## Files

- `baseline_agent.py` - rule-based agent and PII-safe metadata logger
- `sample_business_data.json` - synthetic inventory, shipment, supplier, and policy data
- `run_demo.py` - runs representative interactions and writes safe logs
- `test_baseline_agent.py` - unit tests for supported and unsafe behavior
- `limitations.md` - baseline limitations and why this version is insufficient
- `logs/` - generated safe interaction logs

## Run

From the `phase2` directory, run the script as a filename:

```text
C:\Users\CHRA\AppData\Local\Python\pythoncore-3.14-64\python.exe run_demo.py
```

The command prints responses and writes metadata-only events to `logs/interactions.jsonl`. Raw user questions, business records, and response text are not written to the log.

## Test

```text
C:\Users\CHRA\AppData\Local\Python\pythoncore-3.14-64\python.exe -m unittest -v
```

Do not use `-m run_demo.py`. The `-m` option expects a module name without the `.py` extension. If running from the project root, use the full script path:

```text
C:\Users\CHRA\AppData\Local\Python\pythoncore-3.14-64\python.exe C:\path\to\CapstoneProject\Solution\phase2\run_demo.py
```

## Safety Boundary

This baseline only provides decision support. It refuses requests to update data, place orders, send notifications, or trigger other actions.
