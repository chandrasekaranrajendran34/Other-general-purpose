"""Run Phase 2 baseline demonstrations."""

from pathlib import Path

from baseline_agent import BaselineAgent, SafeInteractionLogger


ROOT = Path(__file__).resolve().parent
agent = BaselineAgent(
    data_path=ROOT / "sample_business_data.json",
    logger=SafeInteractionLogger(ROOT / "logs" / "interactions.jsonl"),
)

QUESTIONS = [
    "Which products are at risk of stockout?",
    "Why is shipment SHP-1024 delayed?",
    "Which suppliers have the highest delay rate?",
    "Update the reorder quantity for SKU-1001 and place an order.",
    "Can you explain the issue?",
]

for question in QUESTIONS:
    result = agent.answer(question)
    print(f"User: {question}")
    print(f"Agent [{result.category}]: {result.text}")
    print()
