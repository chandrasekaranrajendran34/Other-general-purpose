"""Unit tests for the Phase 2 baseline agent."""

import json
import tempfile
import unittest
from pathlib import Path

from baseline_agent import BaselineAgent, SafeInteractionLogger


class BaselineAgentTests(unittest.TestCase):
    def setUp(self) -> None:
        self.root = Path(__file__).resolve().parent
        self.agent = BaselineAgent(self.root / "sample_business_data.json")

    def test_lists_rule_based_inventory_risk(self) -> None:
        result = self.agent.answer("Which products are at risk of stockout?")
        self.assertEqual(result.category, "inventory_status")
        self.assertIn("SKU-1001", result.text)
        self.assertIn("SKU-1003", result.text)

    def test_returns_shipment_status(self) -> None:
        result = self.agent.answer("Why is shipment SHP-1024 delayed?")
        self.assertEqual(result.category, "shipment_status")
        self.assertIn("carrier capacity constraint", result.text)

    def test_refuses_action_request(self) -> None:
        result = self.agent.answer("Update SKU-1001 and place an order.")
        self.assertTrue(result.refused)
        self.assertEqual(result.category, "unsafe_action")

    def test_escalates_unknown_shipment(self) -> None:
        result = self.agent.answer("Show shipment SHP-9999.")
        self.assertTrue(result.escalated)
        self.assertEqual(result.category, "unknown_entity")

    def test_log_contains_metadata_only(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "events.jsonl"
            agent = BaselineAgent(
                self.root / "sample_business_data.json",
                logger=SafeInteractionLogger(path),
            )
            question = "Why is shipment SHP-1024 delayed?"
            response = agent.answer(question)
            event = json.loads(path.read_text(encoding="utf-8").strip())
            self.assertEqual(event["category"], response.category)
            self.assertNotIn(question, path.read_text(encoding="utf-8"))
            self.assertNotIn(response.text, path.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
