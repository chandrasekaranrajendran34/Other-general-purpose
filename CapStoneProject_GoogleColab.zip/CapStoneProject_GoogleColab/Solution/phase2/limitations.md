# Phase 2 Baseline Limitations

## Demonstrated limitations

1. **Rigid wording and routing**

   The agent relies on keyword matching. A question using an unfamiliar synonym, a compound question, or a different sentence structure may be routed incorrectly or classified as unsupported.

2. **No semantic understanding or retrieval**

   The agent only reads the small JSON fixture and cannot search a document collection, interpret policies, or connect related facts across sources.

3. **No forecasting or calculation**

   It reports the stored `status` field. It does not calculate demand, lead time, stockout dates, confidence, or freshness risk.

4. **Limited entity recognition**

   Only identifiers matching the narrow `SKU-0000` and `SHP-0000` formats are recognized.

5. **Template responses**

   Responses are repetitive and cannot adapt their detail to the user's context or explain a multi-step analysis.

6. **Simple safety matching**

   Action refusal is based on a fixed list of phrases. It is useful as a baseline guardrail but cannot reliably understand indirect or adversarial action requests.

## Why this is insufficient for real users

Real operations questions use varied language, require multiple sources, and often contain incomplete or conflicting evidence. The baseline cannot provide reliable evidence citations, robust uncertainty reasoning, multi-turn context, or adaptive behavior. These limitations motivate Phase 3 LLM integration and the later retrieval, tool, memory, and evaluation phases.
