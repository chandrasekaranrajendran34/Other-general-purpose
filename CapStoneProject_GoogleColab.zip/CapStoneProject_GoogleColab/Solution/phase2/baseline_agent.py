"""Dependency-free Phase 2 baseline for the Inventory Operations Copilot."""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ACTION_TERMS = (
    "update",
    "change",
    "modify",
    "delete",
    "remove",
    "place an order",
    "create an order",
    "send an email",
    "notify",
    "trigger",
)


@dataclass(frozen=True)
class AgentResponse:
    """A response returned by the baseline agent."""

    category: str
    text: str
    escalated: bool = False
    refused: bool = False


class SafeInteractionLogger:
    """Write metadata-only interaction events.

    The logger intentionally excludes the raw question, response, business
    identifiers, and business records from the persisted event.
    """

    def __init__(self, path: Path) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def log(self, question: str, response: AgentResponse) -> None:
        event = {
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            "question_sha256": hashlib.sha256(
                question.encode("utf-8")
            ).hexdigest(),
            "question_length": len(question),
            "category": response.category,
            "escalated": response.escalated,
            "refused": response.refused,
            "response_length": len(response.text),
        }
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(event) + "\n")


class BaselineAgent:
    """Simple rules/templates agent used as the Phase 2 baseline."""

    def __init__(self, data_path: Path, logger: SafeInteractionLogger | None = None):
        self.data = self._load_data(data_path)
        self.logger = logger

    @staticmethod
    def _load_data(data_path: Path) -> dict[str, Any]:
        with data_path.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
        if not isinstance(data, dict):
            raise ValueError("Business data must be a JSON object.")
        return data

    def answer(self, question: str) -> AgentResponse:
        if not question or not question.strip():
            response = AgentResponse(
                category="invalid_input",
                text="Please provide an operations question to investigate.",
                escalated=True,
            )
        else:
            normalized = " ".join(question.lower().split())
            response = self._route(normalized)

        if self.logger is not None:
            self.logger.log(question, response)
        return response

    def _route(self, question: str) -> AgentResponse:
        if any(term in question for term in ACTION_TERMS):
            return AgentResponse(
                category="unsafe_action",
                text=(
                    "I cannot modify records, place orders, send notifications, "
                    "or trigger business actions. I can summarize the available "
                    "information for review by a human analyst."
                ),
                refused=True,
            )

        shipment_id = self._find_identifier(question, r"\bshp-\d{4}\b")
        if shipment_id or "shipment" in question:
            return self._shipment_response(shipment_id)

        product_id = self._find_identifier(question, r"\bsku-\d{4}\b")
        if product_id or "stockout" in question or "inventory" in question:
            return self._inventory_response(product_id)

        if "supplier" in question or "delay rate" in question:
            return self._supplier_response()

        return AgentResponse(
            category="unsupported",
            text=(
                "I can investigate inventory, shipment delays, and supplier "
                "performance. Please provide a specific question or identifier."
            ),
            escalated=True,
        )

    def _inventory_response(self, product_id: str | None) -> AgentResponse:
        products = self.data.get("inventory", [])
        if product_id is not None:
            record = next(
                (
                    item
                    for item in products
                    if item.get("product_id", "").lower() == product_id
                ),
                None,
            )
            if record is None:
                return AgentResponse(
                    category="unknown_entity",
                    text=f"No inventory record was found for {product_id.upper()}.",
                    escalated=True,
                )
            return AgentResponse(
                category="inventory_status",
                text=(
                    f"{product_id.upper()} has {record['on_hand']} units on hand "
                    f"against a reorder point of {record['reorder_point']}. "
                    f"Status: {record['status']}. "
                    "This baseline does not calculate future demand or lead-time risk."
                ),
            )

        at_risk = [
            item["product_id"].upper()
            for item in products
            if item.get("status") == "at_risk"
        ]
        if not at_risk:
            return AgentResponse(
                category="inventory_status",
                text="No at-risk products are listed in the baseline data.",
            )
        return AgentResponse(
            category="inventory_status",
            text=(
                "Products marked at risk in the baseline data: "
                + ", ".join(at_risk)
                + ". This is a rule-based status, not a forecast."
            ),
        )

    def _shipment_response(self, shipment_id: str | None) -> AgentResponse:
        if shipment_id is None:
            return AgentResponse(
                category="missing_identifier",
                text="Please provide a shipment identifier such as SHP-1024.",
                escalated=True,
            )

        shipments = self.data.get("shipments", [])
        record = next(
            (
                item
                for item in shipments
                if item.get("shipment_id", "").lower() == shipment_id
            ),
            None,
        )
        if record is None:
            return AgentResponse(
                category="unknown_entity",
                text=f"No shipment record was found for {shipment_id.upper()}.",
                escalated=True,
            )
        return AgentResponse(
            category="shipment_status",
            text=(
                f"{shipment_id.upper()} is {record['status']}. "
                f"Reason recorded: {record['reason']}. "
                f"Last updated: {record['last_updated']}."
            ),
        )

    def _supplier_response(self) -> AgentResponse:
        suppliers = self.data.get("suppliers", [])
        if not suppliers:
            return AgentResponse(
                category="missing_data",
                text="Supplier performance data is unavailable.",
                escalated=True,
            )
        ranking = sorted(
            suppliers,
            key=lambda item: item.get("delay_rate", 0),
            reverse=True,
        )
        summary = ", ".join(
            f"{item['supplier_id'].upper()} ({item['delay_rate']:.0%})"
            for item in ranking
        )
        return AgentResponse(
            category="supplier_performance",
            text=f"Supplier delay rates in the baseline data: {summary}.",
        )

    @staticmethod
    def _find_identifier(question: str, pattern: str) -> str | None:
        match = re.search(pattern, question)
        return match.group(0) if match else None
