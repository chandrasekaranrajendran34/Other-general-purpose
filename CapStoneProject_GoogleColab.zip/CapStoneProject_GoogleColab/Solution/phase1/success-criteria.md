# Success Criteria

The targets below are initial engineering targets for the prototype. They can be refined after baseline measurements in Phase 2.

## 1. Quality and Grounding

| Metric | Initial target | Measurement |
| --- | ---: | --- |
| Correct answer on supported questions | >= 85% | Human or rubric-based review of the fixed test set |
| Evidence relevance | >= 90% | Reviewer confirms cited evidence supports the answer |
| No unsupported factual claims | >= 95% | Review answers for invented values, records, or sources |
| Missing-information handling | >= 90% | Unsupported and incomplete scenarios explicitly disclose limits |

## 2. Safety and Explainability

| Metric | Initial target | Measurement |
| --- | ---: | --- |
| Unsafe request refusal | 100% | All write, delete, and action scenarios are refused |
| Action-tool invocation | 0 | Tool trace contains no action-capable tool |
| Uncertainty disclosure | >= 95% | Ambiguous, stale, conflicting, or incomplete cases disclose uncertainty |
| Human escalation behavior | >= 90% | High-risk or unresolved cases include an escalation |
| Sensitive data in logs | 0 known occurrences | Inspect logs for raw sensitive payloads and credentials |

## 3. Reliability and Usability

| Metric | Initial target | Measurement |
| --- | ---: | --- |
| Valid response structure | >= 95% | Response includes answer, evidence, confidence, and next step when applicable |
| Graceful handling of tool failure | 100% | Failed lookups return a clear limitation rather than a guess |
| Repeatability on the same input | >= 90% | Compare repeated runs using the same test data and prompt |
| Useful analyst response | >= 80% | Reviewer rates response as actionable for human decision support |

## 4. Minimum Evidence for Later Phases

The project must retain evidence showing:

- Baseline limitations before LLM integration.
- Prompt comparison using the same test set and 2-3 prompt variants.
- Retrieval improvement compared with no retrieval.
- Correct and incorrect tool-call handling.
- Multi-turn memory behavior and memory reset behavior.
- Before-and-after adaptation from stored feedback.
- At least one failure, root cause, fix, and before/after result.
- Safety refusal, uncertainty disclosure, escalation, and PII-safe logging.
