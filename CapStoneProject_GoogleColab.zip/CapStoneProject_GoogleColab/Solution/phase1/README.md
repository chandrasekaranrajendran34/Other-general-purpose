# Phase 1 - Problem Framing and Success Definition

This phase defines the business problem, users, workflow, boundaries, success criteria, and initial evaluation scenarios for the LangChain AI Operations Copilot.

## Phase 1 Contents

- `problem-framing.md` - business context, persona, scope, assumptions, and requirements
- `success-criteria.md` - measurable quality, safety, reliability, and usability targets
- `test-scenarios.yaml` - initial fixed scenarios for future phases and evaluation
- `workflow.puml` - workflow diagram source

## Chosen Workflow

The agent supports an operations analyst investigating inventory risk, shipment delays, and supplier performance. It provides evidence-based decision support using read-only information sources.

The agent must not update records, place orders, contact suppliers, or trigger any operational action.
