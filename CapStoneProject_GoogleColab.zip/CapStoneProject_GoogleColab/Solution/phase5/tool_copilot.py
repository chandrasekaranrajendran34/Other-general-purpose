"""Phase 5: typed, read-only tools for an offline inventory copilot.

The implementation intentionally uses only the Python standard library.  Tool
inputs and outputs are validated at the boundary so a future model cannot
silently turn a lookup into a write operation.
"""

from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable, Generic, TypeVar

T = TypeVar("T")
SIMPLE_ID = re.compile(r"^(SKU|SHP)-\d{4}$", re.IGNORECASE)
ACTION_TERMS = re.compile(
    r"\b(update|change|modify|delete|remove|create|place|order|purchase|"
    r"send|notify|trigger|cancel)\b",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class InventoryRecord:
    product_id: str
    on_hand: int
    reorder_point: int
    status: str


@dataclass(frozen=True)
class ShipmentRecord:
    shipment_id: str
    status: str
    reason: str
    last_updated: str


@dataclass(frozen=True)
class SupplierRecord:
    supplier_id: str
    delay_rate: float


@dataclass(frozen=True)
class InventoryLookup:
    product_id: str | None = None


@dataclass(frozen=True)
class ShipmentLookup:
    shipment_id: str


@dataclass(frozen=True)
class EmptyInput:
    """Explicit input schema for tools without arguments."""


@dataclass(frozen=True)
class ToolResult(Generic[T]):
    tool_name: str
    ok: bool
    value: T | None = None
    error_code: str | None = None
    error_message: str | None = None


@dataclass(frozen=True)
class ToolCall:
    tool_name: str
    arguments: dict[str, Any]


class ReadOnlyTool:
    """A named tool with a typed validator and a read-only callable."""

    def __init__(
        self,
        name: str,
        input_type: type[Any],
        output_type: type[Any],
        handler: Callable[[Any], Any],
    ) -> None:
        self.name = name
        self.input_type = input_type
        self.output_type = output_type
        self.handler = handler

    def invoke(self, arguments: dict[str, Any]) -> ToolResult[Any]:
        try:
            typed_input = self._validate(arguments)
            value = self.handler(typed_input)
            if not isinstance(value, self.output_type):
                raise TypeError(
                    f"expected {self.output_type.__name__}, got {type(value).__name__}"
                )
            return ToolResult(self.name, True, value=value)
        except LookupError as exc:
            return ToolResult(self.name, False, error_code="not_found",
                              error_message=str(exc))
        except (TypeError, ValueError) as exc:
            return ToolResult(self.name, False, error_code="invalid_input",
                              error_message=str(exc))
        except Exception:
            # Do not expose exception details that may contain internal data.
            return ToolResult(self.name, False, error_code="tool_error",
                              error_message="The read-only lookup failed.")

    def _validate(self, arguments: dict[str, Any]) -> Any:
        if self.input_type is EmptyInput:
            if arguments:
                raise ValueError("This tool does not accept arguments.")
            return EmptyInput()
        if self.input_type is ShipmentLookup:
            if set(arguments) != {"shipment_id"}:
                raise ValueError("Only shipment_id is accepted.")
            value = arguments.get("shipment_id")
            if not isinstance(value, str) or not SIMPLE_ID.fullmatch(value):
                raise ValueError("shipment_id must match SHP-0000.")
            if not value.upper().startswith("SHP-"):
                raise ValueError("shipment_id must be a shipment identifier.")
            return ShipmentLookup(value.upper())
        if self.input_type is InventoryLookup:
            if set(arguments) - {"product_id"}:
                raise ValueError("Only product_id is accepted.")
            value = arguments.get("product_id")
            if value is not None and (
                not isinstance(value, str)
                or not re.fullmatch(r"SKU-\d{4}", value, re.IGNORECASE)
            ):
                raise ValueError("product_id must match SKU-0000.")
            return InventoryLookup(value.upper() if value else None)
        raise TypeError("No validator is registered for this tool.")


class ReadOnlyToolRegistry:
    """Registry that exposes only explicitly registered read-only tools."""

    def __init__(self, data_path: Path) -> None:
        raw = json.loads(data_path.read_text(encoding="utf-8"))
        self.inventory = tuple(InventoryRecord(**item) for item in raw["inventory"])
        self.shipments = tuple(ShipmentRecord(**item) for item in raw["shipments"])
        self.suppliers = tuple(SupplierRecord(**item) for item in raw["suppliers"])
        self.tools: dict[str, ReadOnlyTool] = {
            "list_inventory": ReadOnlyTool(
                "list_inventory", InventoryLookup, list, self._list_inventory
            ),
            "get_shipment": ReadOnlyTool(
                "get_shipment", ShipmentLookup, ShipmentRecord, self._get_shipment
            ),
            "list_supplier_delays": ReadOnlyTool(
                "list_supplier_delays", EmptyInput, list, self._list_suppliers
            ),
        }

    def call(self, call: ToolCall) -> ToolResult[Any]:
        tool = self.tools.get(call.tool_name)
        if tool is None:
            return ToolResult(call.tool_name, False, error_code="unknown_tool",
                              error_message="That tool is not available.")
        return tool.invoke(dict(call.arguments))

    def _list_inventory(self, request: InventoryLookup) -> list[InventoryRecord]:
        if request.product_id is None:
            return list(self.inventory)
        matches = [x for x in self.inventory if x.product_id == request.product_id]
        if not matches:
            raise LookupError("No approved inventory record was found.")
        return matches

    def _get_shipment(self, request: ShipmentLookup) -> ShipmentRecord:
        for item in self.shipments:
            if item.shipment_id == request.shipment_id:
                return item
        raise LookupError("No approved shipment record was found.")

    def _list_suppliers(self, _: EmptyInput) -> list[SupplierRecord]:
        return list(self.suppliers)


@dataclass(frozen=True)
class CopilotResponse:
    text: str
    category: str
    tool_calls: tuple[ToolCall, ...] = ()
    tool_results: tuple[ToolResult[Any], ...] = ()
    refused: bool = False
    escalated: bool = False


class ToolAgent:
    """Rule-based router demonstrating model-tool safeguards offline."""

    def __init__(self, registry: ReadOnlyToolRegistry, max_tool_calls: int = 3):
        self.registry = registry
        self.max_tool_calls = max_tool_calls

    def answer(self, question: str) -> CopilotResponse:
        if not isinstance(question, str):
            return CopilotResponse(
                "Please provide an operations question as text.",
                "invalid_input", escalated=True,
            )
        normalized = " ".join(question.strip().split())
        if not normalized:
            return CopilotResponse("Please provide an operations question.",
                                   "invalid_input", escalated=True)
        if ACTION_TERMS.search(normalized):
            return CopilotResponse(
                "I cannot modify records, place orders, notify people, or trigger "
                "actions. I can perform read-only lookups for human review.",
                "unsafe_action", refused=True,
            )
        calls = self._route(normalized)
        if calls is None:
            return CopilotResponse(
                "Please ask about inventory, a shipment, or supplier delay rates "
                "and include an identifier when one is needed.",
                "ambiguous", escalated=True,
            )
        return self.execute_calls(calls)

    def execute_calls(self, calls: list[ToolCall]) -> CopilotResponse:
        """Execute a proposed sequence with duplicate and count safeguards."""
        if not calls:
            return CopilotResponse(
                "No read-only lookup was proposed; please clarify the request.",
                "ambiguous", escalated=True,
            )
        seen: set[tuple[str, str]] = set()
        results: list[ToolResult[Any]] = []
        executed: list[ToolCall] = []
        for call in calls:
            signature = (call.tool_name, json.dumps(call.arguments, sort_keys=True))
            if signature in seen:
                return CopilotResponse(
                    "I stopped because the same lookup was requested repeatedly.",
                    "loop_prevented", tuple(executed), tuple(results), escalated=True,
                )
            if len(executed) >= self.max_tool_calls:
                return CopilotResponse(
                    "I stopped after the read-only tool-call limit. Please review "
                    "the partial evidence with a human analyst.",
                    "loop_prevented", tuple(executed), tuple(results), escalated=True,
                )
            seen.add(signature)
            executed.append(call)
            results.append(self.registry.call(call))
        return self._compose("", tuple(executed), tuple(results))

    def _route(self, question: str) -> list[ToolCall] | None:
        shipment = re.search(r"\bSHP-\d{4}\b", question, re.IGNORECASE)
        product = re.search(r"\bSKU-\d{4}\b", question, re.IGNORECASE)
        if shipment or "shipment" in question.lower():
            if shipment:
                return [ToolCall("get_shipment",
                                 {"shipment_id": shipment.group(0).upper()})]
            return None
        if product or any(word in question.lower() for word in ("inventory", "stockout")):
            return [ToolCall("list_inventory",
                             {"product_id": product.group(0).upper() if product else None})]
        if "supplier" in question.lower() or "delay rate" in question.lower():
            return [ToolCall("list_supplier_delays", {})]
        return None

    @staticmethod
    def _compose(
        question: str, calls: tuple[ToolCall, ...], results: tuple[ToolResult[Any], ...]
    ) -> CopilotResponse:
        del question
        failure = next((r for r in results if not r.ok), None)
        if failure:
            return CopilotResponse(
                f"The read-only lookup did not complete ({failure.error_code}). "
                "I will not guess from a failed call; please verify the identifier "
                "or escalate to an analyst.",
                "tool_failure", calls, results, escalated=True,
            )
        value = results[0].value
        if calls[0].tool_name == "get_shipment":
            record = value
            assert isinstance(record, ShipmentRecord)
            return CopilotResponse(
                f"{record.shipment_id} is {record.status}. Reason recorded: "
                f"{record.reason}. Last updated: {record.last_updated}. "
                "This is a read-only result; confirm freshness before acting.",
                "shipment_status", calls, results,
            )
        if calls[0].tool_name == "list_supplier_delays":
            ranking = sorted(value, key=lambda item: item.delay_rate, reverse=True)
            text = "Supplier delay rates: " + ", ".join(
                f"{item.supplier_id} ({item.delay_rate:.0%})" for item in ranking
            )
            return CopilotResponse(text, "supplier_performance", calls, results)
        records = value
        text = "Inventory records: " + ", ".join(
            f"{item.product_id} {item.on_hand} on hand (status {item.status})"
            for item in records
        )
        return CopilotResponse(text, "inventory_status", calls, results)


def build_offline_agent(data_path: Path | None = None) -> ToolAgent:
    path = data_path or Path(__file__).with_name("synthetic_data.json")
    return ToolAgent(ReadOnlyToolRegistry(path))


def response_to_dict(response: CopilotResponse) -> dict[str, Any]:
    return {
        "text": response.text,
        "category": response.category,
        "refused": response.refused,
        "escalated": response.escalated,
        "tool_calls": [asdict(call) for call in response.tool_calls],
        "tool_results": [
            {
                "tool_name": result.tool_name,
                "ok": result.ok,
                "error_code": result.error_code,
            }
            for result in response.tool_results
        ],
    }
