# Phase 5 - Safe read-only tool use

`tool_copilot.py` demonstrates typed input/output schemas, deterministic routing,
an allow-listed tool registry, explicit failed-call handling, duplicate/maximum
call loop prevention, and refusal of unsafe actions. Tools can only read the
synthetic records in `synthetic_data.json`; there is no write tool.

Run offline from this directory:

```text
python run_demo.py
python -m unittest -v
```

No API key or third-party package is required. Tool results never become an
instruction to perform an operational action. Failed or missing lookups are
reported rather than guessed.
