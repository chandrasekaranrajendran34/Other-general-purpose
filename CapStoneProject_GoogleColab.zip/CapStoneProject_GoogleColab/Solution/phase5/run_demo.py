"""Run Phase 5 read-only routing examples."""

from __future__ import annotations

import json
from pathlib import Path

from tool_copilot import build_offline_agent, response_to_dict


def main() -> None:
    agent = build_offline_agent()
    questions = [
        "Which products are at risk of stockout?",
        "Why is shipment SHP-1024 delayed?",
        "Update SKU-1001 and place an order.",
        "Show shipment SHP-9999.",
    ]
    for question in questions:
        response = agent.answer(question)
        print(json.dumps({"question": question, "response": response_to_dict(response)},
                         indent=2))


if __name__ == "__main__":
    main()
