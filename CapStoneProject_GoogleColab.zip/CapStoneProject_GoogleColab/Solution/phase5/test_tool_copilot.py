"""Offline tests for typed tools and safety boundaries."""

import unittest
from pathlib import Path

from tool_copilot import (
    ReadOnlyToolRegistry, ToolAgent, ToolCall, build_offline_agent,
)


class ToolCopilotTests(unittest.TestCase):
    def setUp(self) -> None:
        self.agent = build_offline_agent()

    def test_typed_shipment_lookup(self) -> None:
        result = self.agent.answer("Why is shipment SHP-1024 delayed?")
        self.assertEqual(result.category, "shipment_status")
        self.assertEqual(result.tool_calls[0].tool_name, "get_shipment")
        self.assertIn("carrier capacity", result.text)

    def test_unsafe_action_is_refused_without_tool_call(self) -> None:
        result = self.agent.answer("Update SKU-1001 and place an order.")
        self.assertTrue(result.refused)
        self.assertFalse(result.tool_calls)

    def test_unknown_entity_is_explicit_failure(self) -> None:
        result = self.agent.answer("Show shipment SHP-9999.")
        self.assertEqual(result.category, "tool_failure")
        self.assertTrue(result.escalated)
        self.assertFalse(result.tool_results[0].ok)

    def test_unknown_tool_and_bad_schema_are_rejected(self) -> None:
        registry = ReadOnlyToolRegistry(Path(__file__).with_name("synthetic_data.json"))
        self.assertEqual(registry.call(ToolCall("write_order", {})).error_code, "unknown_tool")
        self.assertEqual(
            registry.call(ToolCall("get_shipment", {"shipment_id": "not-an-id"})).error_code,
            "invalid_input",
        )
        self.assertEqual(
            registry.call(ToolCall("list_inventory", {"unexpected": "value"})).error_code,
            "invalid_input",
        )

    def test_duplicate_calls_are_stopped(self) -> None:
        response = self.agent.execute_calls([
            ToolCall("get_shipment", {"shipment_id": "SHP-1024"}),
            ToolCall("get_shipment", {"shipment_id": "SHP-1024"}),
        ])
        self.assertEqual(response.category, "loop_prevented")
        self.assertTrue(response.escalated)

    def test_ambiguous_question_does_not_guess(self) -> None:
        result = self.agent.answer("What is the issue with operations?")
        self.assertEqual(result.category, "ambiguous")
        self.assertTrue(result.escalated)


if __name__ == "__main__":
    unittest.main()
