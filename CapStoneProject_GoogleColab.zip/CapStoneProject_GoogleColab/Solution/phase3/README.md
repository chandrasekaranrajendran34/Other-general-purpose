# Phase 3 - LLM Integration and Prompt Comparison

This phase integrates Together AI through LangChain and compares three prompt strategies against the same fixed test set from Phase 1.

## Files

- `llm_agent.py` - Together AI adapter, prompt variants, safety pre-check, and metadata-only logging
- `run_comparison.py` - runs all prompt variants against the same Phase 1 scenarios
- `test_llm_agent.py` - offline unit tests
- `requirements.txt` - LangChain dependencies (`langchain-core`, `langchain-together`)
- `TOGETHER_SETUP.md` - Together AI configuration
- `outputs/` - generated comparison results and markdown table
- `logs/` - metadata-only execution logs

## Prompt variants

1. **basic** - concise instruction with minimal structure
2. **structured** - explicit response sections for answer, evidence, uncertainty, and next step
3. **safety_focused** - structured response plus strict refusal and escalation rules

The default strategy is `safety_focused` because the project prioritizes safe decision support over the shortest response.

## Offline demonstration

```text
C:\Users\CHRA\AppData\Local\Python\pythoncore-3.14-64\python.exe run_comparison.py --offline
```

Offline mode uses deterministic responses and does not call Together AI.

## Together AI mode

Install dependencies:

```text
C:\Users\CHRA\AppData\Local\Python\pythoncore-3.14-64\python.exe -m pip install -r requirements.txt
```

Configure the key in the current terminal:

```powershell
$env:TOGETHER_API_KEY = "your-key"
$env:TOGETHER_MODEL = "meta-llama/Llama-3.3-70B-Instruct-Turbo"
$env:TOGETHER_BASE_URL = "https://api.together.xyz/v1"
C:\Users\CHRA\AppData\Local\Python\pythoncore-3.14-64\python.exe run_comparison.py
```

The API key must never be committed, printed, or included in screenshots. Authentication uses `TOGETHER_API_KEY` with the native `langchain_together.ChatTogether` client; no OpenAI key is used. `TOGETHER_BASE_URL` is optional and only needed to override the default Together endpoint.

## Test

```text
C:\Users\CHRA\AppData\Local\Python\pythoncore-3.14-64\python.exe -m unittest -v
```

## Comparison evidence

The generated `outputs/prompt-comparison.md` contains:

| Prompt | Output | What improved | What worsened |
| --- | --- | --- | --- |
| Prompt variant | Model response | Observed benefit | Observed limitation |

All variants are run against the same test set so the comparison is controlled.
