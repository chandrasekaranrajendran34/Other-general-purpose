# Together AI Configuration

Phase 3 uses the native LangChain Together AI client (`langchain_together.ChatTogether`). No OpenAI key or OpenAI package is required; authentication uses `TOGETHER_API_KEY` only.

```powershell
$env:TOGETHER_API_KEY = "your-key"
$env:TOGETHER_MODEL = "meta-llama/Llama-3.3-70B-Instruct-Turbo"
$env:TOGETHER_BASE_URL = "https://api.together.xyz/v1"
C:\Users\CHRA\AppData\Local\Python\pythoncore-3.14-64\python.exe run_comparison.py
```

The API key must not be stored in source files, logs, screenshots, or repositories.

The offline command remains available:

```powershell
C:\Users\CHRA\AppData\Local\Python\pythoncore-3.14-64\python.exe run_comparison.py --offline
```

Phase 4 retrieval uses embeddings separately. The Llama model is a chat model and cannot be used as an embedding model.
