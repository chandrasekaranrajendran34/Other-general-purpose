"""Run Phase 3 prompt comparison against the fixed Phase 1 test set."""

from __future__ import annotations

import argparse
from pathlib import Path

from llm_agent import (
    DEFAULT_VARIANT,
    LangChainTogetherClient,
    OfflineClient,
    PROMPT_VARIANTS,
    PromptComparisonAgent,
    SafeLLMLogger,
    load_phase1_questions,
    write_markdown,
    write_results,
)


ROOT = Path(__file__).resolve().parent
PHASE1_SCENARIOS = ROOT.parent / "phase1" / "test-scenarios.yaml"


def build_client(offline: bool):
    return OfflineClient() if offline else LangChainTogetherClient()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--offline",
        action="store_true",
        help="Use deterministic responses without an API key.",
    )
    args = parser.parse_args()

    questions = load_phase1_questions(PHASE1_SCENARIOS)
    agent = PromptComparisonAgent(
        client=build_client(args.offline),
        logger=SafeLLMLogger(ROOT / "logs" / "llm_interactions.jsonl"),
    )
    results = []
    for scenario in questions:
        for variant_name in PROMPT_VARIANTS:
            result = agent.run(variant_name, scenario["prompt"])
            result["scenario_id"] = scenario["id"]
            results.append(result)
            print(
                f"{scenario['id']} | {variant_name} | "
                f"{result['status']} | {result['output'][:100]}"
            )

    write_results(ROOT / "outputs" / "prompt-comparison.json", results)
    write_markdown(ROOT / "outputs" / "prompt-comparison.md", results)
    print(f"Default prompt: {DEFAULT_VARIANT}")
    print("Wrote outputs/prompt-comparison.json and outputs/prompt-comparison.md")


if __name__ == "__main__":
    main()
