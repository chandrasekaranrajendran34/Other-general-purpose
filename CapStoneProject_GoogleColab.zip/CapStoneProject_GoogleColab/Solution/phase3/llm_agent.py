"""Phase 3 LangChain integration and prompt comparison support."""

from __future__ import annotations

import hashlib
import json
import os
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Protocol


PROMPT_VARIANTS = ("basic", "structured", "safety_focused")
DEFAULT_TOGETHER_MODEL = "meta-llama/Llama-3.3-70B-Instruct-Turbo"
DEFAULT_TOGETHER_BASE_URL = "https://api.together.xyz/v1"
DEFAULT_VARIANT = "safety_focused"
ACTION_PATTERN = re.compile(
    r"\b(update|change|modify|delete|remove|place an order|create an order|"
    r"send an email|notify|trigger)\b",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class PromptVariant:
    name: str
    system_prompt: str
    improvement: str
    limitation: str


PROMPTS: dict[str, PromptVariant] = {
    "basic": PromptVariant(
        name="basic",
        system_prompt=(
            "You are an inventory operations assistant. Answer the user's "
            "question using only the supplied context."
        ),
        improvement="Establishes a minimal LLM baseline with low prompt complexity.",
        limitation="May omit evidence, uncertainty, or an explicit next step.",
    ),
    "structured": PromptVariant(
        name="structured",
        system_prompt=(
            "You are an inventory operations decision-support assistant. Use "
            "only the supplied context and do not invent facts. Format every "
            "answer with: Answer, Evidence, Uncertainty, and Recommended next step."
        ),
        improvement="Makes evidence and uncertainty more consistent.",
        limitation="The fixed structure may be verbose for simple questions.",
    ),
    "safety_focused": PromptVariant(
        name="safety_focused",
        system_prompt=(
            "You are a safety-first inventory operations copilot providing "
            "decision support only. Use only supplied context. Never claim an "
            "unknown fact. Refuse requests to update, delete, purchase, notify, "
            "or trigger actions. For incomplete, conflicting, stale, sensitive, "
            "or high-risk information, explain the uncertainty and escalate to "
            "a human analyst. Format every answer with: Answer, Evidence, "
            "Uncertainty, and Human next step."
        ),
        improvement="Strengthens refusal, uncertainty, and escalation behavior.",
        limitation="May refuse or escalate more often than a less restrictive prompt.",
    ),
}


class ChatClient(Protocol):
    def invoke(self, system_prompt: str, user_prompt: str) -> str:
        """Return an LLM response for the supplied messages."""


class LangChainTogetherClient:
    """LangChain chat adapter for Together AI, authenticated with TOGETHER_API_KEY."""

    def __init__(self, model: str | None = None) -> None:
        api_key = os.environ.get("TOGETHER_API_KEY")
        if not api_key:
            raise RuntimeError(
                "TOGETHER_API_KEY is not set. Use --offline or configure the "
                "key as an environment variable."
            )
        try:
            from langchain_together import ChatTogether
            from langchain_core.messages import HumanMessage, SystemMessage
        except ImportError as exc:
            raise RuntimeError(
                "LLM dependencies are missing. Install requirements.txt or use --offline."
            ) from exc

        self._chat_together = ChatTogether(
            model=model
            or os.environ.get("TOGETHER_MODEL", DEFAULT_TOGETHER_MODEL),
            temperature=0,
            together_api_key=api_key,
            base_url=os.environ.get(
                "TOGETHER_BASE_URL", DEFAULT_TOGETHER_BASE_URL
            ),
        )
        self._system_message = SystemMessage
        self._human_message = HumanMessage

    def invoke(self, system_prompt: str, user_prompt: str) -> str:
        result = self._chat_together.invoke(
            [
                self._system_message(content=system_prompt),
                self._human_message(content=user_prompt),
            ]
        )
        content = result.content
        if not isinstance(content, str):
            raise RuntimeError("The LLM returned a non-text response.")
        return content


class OfflineClient:
    """Deterministic client for tests and demonstration without an API key."""

    def invoke(self, system_prompt: str, user_prompt: str) -> str:
        del system_prompt
        if ACTION_PATTERN.search(user_prompt):
            return (
                "Answer: I cannot perform or trigger that action.\n"
                "Evidence: The copilot is decision-support only.\n"
                "Uncertainty: No action was attempted.\n"
                "Human next step: Ask a human analyst to use the approved process."
            )
        return (
            "Answer: The available context should be reviewed for this question.\n"
            "Evidence: Offline mode does not call an LLM or retrieve business data.\n"
            "Uncertainty: This is a deterministic workflow response, not an analysis.\n"
            "Human next step: Validate the answer against approved business records."
        )


class SafeLLMLogger:
    """Persist execution metadata without raw prompts or model responses."""

    def __init__(self, path: Path) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def log(
        self,
        variant: str,
        question: str,
        output: str,
        status: str,
    ) -> None:
        event = {
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            "variant": variant,
            "question_sha256": hashlib.sha256(
                question.encode("utf-8")
            ).hexdigest(),
            "question_length": len(question),
            "output_length": len(output),
            "status": status,
        }
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(event) + "\n")


class PromptComparisonAgent:
    """Run the same question through selected prompt strategies."""

    def __init__(
        self,
        client: ChatClient,
        logger: SafeLLMLogger | None = None,
    ) -> None:
        self.client = client
        self.logger = logger

    def run(self, variant_name: str, question: str) -> dict[str, Any]:
        if variant_name not in PROMPTS:
            raise ValueError(f"Unknown prompt variant: {variant_name}")
        variant = PROMPTS[variant_name]
        status = "success"
        output = ""
        try:
            output = self.client.invoke(variant.system_prompt, question)
        except Exception as exc:
            status = "error"
            output = f"LLM invocation failed: {exc}"
        if self.logger is not None:
            self.logger.log(variant_name, question, output, status)
        return {
            "variant": variant_name,
            "question": question,
            "output": output,
            "status": status,
            "improvement": variant.improvement,
            "limitation": variant.limitation,
        }


def load_phase1_questions(path: Path) -> list[dict[str, str]]:
    """Load the simple prompt fields from the Phase 1 YAML scenario file.

    The Phase 1 file intentionally uses a small, dependency-free YAML shape.
    This parser reads only the quoted `id` and `prompt` fields needed here.
    """

    scenarios: list[dict[str, str]] = []
    current_id: str | None = None
    for line in path.read_text(encoding="utf-8").splitlines():
        id_match = re.match(r"\s*-\s+id:\s+(\S+)", line)
        if id_match:
            current_id = id_match.group(1)
            continue
        prompt_match = re.match(r'\s*prompt:\s+"(.*)"\s*$', line)
        if prompt_match and current_id is not None:
            scenarios.append(
                {"id": current_id, "prompt": prompt_match.group(1)}
            )
            current_id = None
    if not scenarios:
        raise ValueError(f"No scenarios found in {path}")
    return scenarios


def write_results(path: Path, results: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(results, indent=2), encoding="utf-8")


def write_markdown(path: Path, results: list[dict[str, Any]]) -> None:
    lines = [
        "# Prompt Comparison",
        "",
        "The same Phase 1 test set was used for every prompt variant.",
        "",
        "| Scenario | Prompt | outputs | What improved | What worsened |",
        "| --- | --- | --- | --- | --- |",
    ]
    for result in results:
        output = result["output"].replace("|", "\\|").replace("\n", "<br>")
        lines.append(
            f"| {result['scenario_id']} | {result['variant']} | {output} | "
            f"{result['improvement']} | {result['limitation']} |"
        )
    lines.extend(
        [
            "",
            "## Default Prompt Decision",
            "",
            "The `safety_focused` variant is the default because the project "
            "requires refusal of operational actions, explicit uncertainty, "
            "and escalation to a human analyst.",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
