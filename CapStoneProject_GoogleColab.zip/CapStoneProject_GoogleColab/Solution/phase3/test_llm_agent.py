"""Offline tests for Phase 3 prompt integration."""

import tempfile
import unittest
from pathlib import Path

from llm_agent import (
    PROMPT_VARIANTS,
    OfflineClient,
    PromptComparisonAgent,
    SafeLLMLogger,
    load_phase1_questions,
    write_markdown,
)


class PromptComparisonTests(unittest.TestCase):
    def setUp(self) -> None:
        self.root = Path(__file__).resolve().parent

    def test_all_prompt_variants_exist(self) -> None:
        self.assertEqual(
            set(PROMPT_VARIANTS),
            {"basic", "structured", "safety_focused"},
        )

    def test_phase1_loader_returns_fixed_test_set(self) -> None:
        scenarios = load_phase1_questions(
            self.root.parent / "phase1" / "test-scenarios.yaml"
        )
        self.assertEqual(len(scenarios), 10)
        self.assertEqual(scenarios[0]["id"], "Q01")

    def test_same_question_can_run_for_each_variant(self) -> None:
        agent = PromptComparisonAgent(OfflineClient())
        results = [
            agent.run(variant, "Which products are at risk?")
            for variant in PROMPT_VARIANTS
        ]
        self.assertEqual([item["status"] for item in results], ["success"] * 3)
        self.assertTrue(all(item["output"] for item in results))

    def test_offline_client_refuses_action(self) -> None:
        agent = PromptComparisonAgent(OfflineClient())
        result = agent.run("safety_focused", "Update SKU-1001 and place an order.")
        self.assertIn("cannot perform", result["output"])

    def test_logger_excludes_raw_content(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "events.jsonl"
            agent = PromptComparisonAgent(
                OfflineClient(), SafeLLMLogger(path)
            )
            question = "What is the stock status of SKU-1001?"
            result = agent.run("basic", question)
            log = path.read_text(encoding="utf-8")
            self.assertNotIn(question, log)
            self.assertNotIn(result["output"], log)

    def test_markdown_contains_comparison_columns(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "comparison.md"
            write_markdown(
                path,
                [
                    {
                        "scenario_id": "Q01",
                        "variant": "basic",
                        "output": "answer",
                        "improvement": "simple",
                        "limitation": "limited",
                    }
                ],
            )
            content = path.read_text(encoding="utf-8")
            self.assertIn("What improved", content)
            self.assertIn("What worsened", content)


if __name__ == "__main__":
    unittest.main()
