"""Phase 6: bounded planning and short-term conversation memory.

This phase keeps only operational context needed for the active conversation.
Memory is bounded by turns and age, can be reset explicitly, and never stores
raw business records or credentials.
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class PlanStep:
    step_id: str
    description: str
    status: str = "pending"


@dataclass(frozen=True)
class Plan:
    goal: str
    steps: tuple[PlanStep, ...]


@dataclass(frozen=True)
class MemoryTurn:
    user_text: str
    category: str
    entity: str | None
    created_at: float


class ShortTermMemory:
    """In-process, bounded memory with age and explicit reset controls."""

    def __init__(self, max_turns: int = 6, ttl_seconds: float = 900.0) -> None:
        if max_turns < 1 or ttl_seconds <= 0:
            raise ValueError("Memory limits must be positive.")
        self.max_turns = max_turns
        self.ttl_seconds = ttl_seconds
        self._turns: list[MemoryTurn] = []

    def add(self, user_text: str, category: str, entity: str | None = None) -> None:
        self._purge()
        self._turns.append(MemoryTurn(user_text, category, entity, time.monotonic()))
        self._turns = self._turns[-self.max_turns :]

    def recent_entity(self, prefix: str | None = None) -> str | None:
        self._purge()
        for turn in reversed(self._turns):
            if turn.entity and (prefix is None or turn.entity.startswith(prefix)):
                return turn.entity
        return None

    def snapshot(self) -> tuple[MemoryTurn, ...]:
        self._purge()
        return tuple(self._turns)

    def reset(self) -> None:
        self._turns.clear()

    def _purge(self) -> None:
        cutoff = time.monotonic() - self.ttl_seconds
        self._turns = [turn for turn in self._turns if turn.created_at >= cutoff]


def make_plan(question: str, memory: ShortTermMemory) -> Plan:
    """Create a transparent plan before any lookup or response."""

    normalized = question.lower()
    steps = [
        PlanStep("classify", "Classify the request and check safety.", "done"),
        PlanStep("identify", "Identify a product, shipment, or reporting scope."),
        PlanStep("evidence", "Use approved read-only evidence."),
        PlanStep("respond", "State evidence, uncertainty, and a human next step."),
    ]
    if "why" in normalized or "status" in normalized:
        steps[2] = PlanStep("evidence", "Retrieve the current status evidence.", "pending")
    if not re.search(r"\b(?:SKU|SHP)-\d{4}\b", question, re.IGNORECASE):
        prior = memory.recent_entity()
        if prior:
            steps[1] = PlanStep(
                "identify", f"Resolve the follow-up to {prior} from short-term memory."
            )
    return Plan(question, tuple(steps))


@dataclass(frozen=True)
class ConversationResponse:
    text: str
    category: str
    plan: Plan
    memory_size: int
    reset: bool = False


class ConversationAgent:
    """Small multi-turn decision-support agent using synthetic evidence."""

    SHIPMENTS = {
        "SHP-1024": ("delayed", "carrier capacity constraint", "2026-09-20")
    }
    INVENTORY = {
        "SKU-1001": (12, 20, "at_risk"),
        "SKU-1003": (4, 15, "at_risk"),
        "SKU-1004": (30, 10, "healthy"),
    }

    def __init__(self, memory: ShortTermMemory | None = None) -> None:
        self.memory = memory or ShortTermMemory()

    def handle(self, question: str) -> ConversationResponse:
        if question.strip().lower() in {"reset", "reset memory", "start over"}:
            self.memory.reset()
            plan = Plan("reset", (PlanStep("reset", "Clear active context.", "done"),))
            return ConversationResponse("Short-term conversation memory was reset.",
                                        "memory_reset", plan, 0, True)
        plan = make_plan(question, self.memory)
        shipment = self._identifier(question, "SHP")
        product = self._identifier(question, "SKU")
        if shipment is None and any(word in question.lower()
                                    for word in ("shipment", "it", "that shipment")):
            shipment = self.memory.recent_entity("SHP")
        if product is None and any(word in question.lower()
                                   for word in ("sku", "it", "that product")):
            product = self.memory.recent_entity("SKU")
        if re.search(r"\b(update|delete|order|notify|send)\b", question, re.IGNORECASE):
            response = ConversationResponse(
                "I cannot perform that action. I can keep read-only context and "
                "summarize evidence for an approved human workflow.",
                "unsafe_action", plan, len(self.memory.snapshot()),
            )
            return response
        if shipment:
            record = self.SHIPMENTS.get(shipment)
            if record is None:
                text, category = f"No approved record was found for {shipment}.", "unknown_entity"
            else:
                text = (f"{shipment} is {record[0]}; recorded reason: {record[1]}. "
                        f"Last updated {record[2]}.")
                category = "shipment_status"
            self.memory.add(question, category, shipment)
            return ConversationResponse(text, category, plan, len(self.memory.snapshot()))
        if product:
            record = self.INVENTORY.get(product)
            if record is None:
                text, category = f"No approved record was found for {product}.", "unknown_entity"
            else:
                text = f"{product}: {record[0]} on hand, reorder point {record[1]}, {record[2]}."
                category = "inventory_status"
            self.memory.add(question, category, product)
            return ConversationResponse(text, category, plan, len(self.memory.snapshot()))
        self.memory.add(question, "clarification")
        return ConversationResponse(
            "Please provide a shipment (for example SHP-1024) or product identifier. "
            "I will not guess which record you mean.",
            "clarification", plan, len(self.memory.snapshot()),
        )

    @staticmethod
    def _identifier(question: str, prefix: str) -> str | None:
        match = re.search(rf"\b{prefix}-\d{{4}}\b", question, re.IGNORECASE)
        return match.group(0).upper() if match else None


def response_to_dict(response: ConversationResponse) -> dict[str, Any]:
    return {
        "text": response.text,
        "category": response.category,
        "memory_size": response.memory_size,
        "reset": response.reset,
        "plan": [{"step_id": s.step_id, "description": s.description, "status": s.status}
                 for s in response.plan.steps],
    }
