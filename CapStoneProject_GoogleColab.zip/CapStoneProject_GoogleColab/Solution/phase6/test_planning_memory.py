import unittest

from planning_memory import ConversationAgent, ShortTermMemory


class PlanningMemoryTests(unittest.TestCase):
    def test_plan_is_transparent(self) -> None:
        response = ConversationAgent().handle("Why is shipment SHP-1024 delayed?")
        self.assertEqual(response.plan.steps[0].status, "done")
        self.assertIn("SHP-1024", response.text)

    def test_follow_up_uses_recent_entity(self) -> None:
        agent = ConversationAgent()
        agent.handle("Show shipment SHP-1024.")
        response = agent.handle("Why is it delayed?")
        self.assertEqual(response.category, "shipment_status")
        self.assertIn("SHP-1024", response.text)
        self.assertEqual(response.memory_size, 2)

    def test_reset_removes_context(self) -> None:
        agent = ConversationAgent()
        agent.handle("Show shipment SHP-1024.")
        reset = agent.handle("reset")
        self.assertTrue(reset.reset)
        response = agent.handle("Why is it delayed?")
        self.assertEqual(response.category, "clarification")

    def test_turn_retention_is_bounded(self) -> None:
        memory = ShortTermMemory(max_turns=2)
        for index in range(4):
            memory.add(f"turn {index}", "test")
        self.assertEqual(len(memory.snapshot()), 2)

    def test_actions_remain_refused(self) -> None:
        response = ConversationAgent().handle("Update SKU-1001.")
        self.assertEqual(response.category, "unsafe_action")


if __name__ == "__main__":
    unittest.main()
