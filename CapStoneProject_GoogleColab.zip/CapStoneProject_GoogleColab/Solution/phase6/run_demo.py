"""Run a multi-turn planning and memory demonstration."""

from planning_memory import ConversationAgent, response_to_dict


def main() -> None:
    agent = ConversationAgent()
    for question in ("Show shipment SHP-1024.", "Why is it delayed?", "reset",
                     "Why is it delayed?"):
        response = agent.handle(question)
        print(f"\nUser: {question}")
        print(response_to_dict(response))


if __name__ == "__main__":
    main()
