# Phase 6 - Planning and short-term memory

`planning_memory.py` creates an inspectable safety-first plan for every turn and
uses bounded, in-process memory to resolve follow-ups such as “Why is it
delayed?” after a shipment lookup. Memory is limited by turn count and TTL,
contains only minimal context, and supports `reset`/`reset memory`.

```text
python run_demo.py
python -m unittest -v
```

Everything is deterministic and uses synthetic records. No API key or package
installation is required. Persistent long-term memory is deliberately out of
scope.
