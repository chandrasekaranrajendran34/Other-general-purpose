# Phase 4 - Knowledge and Retrieval

This phase adds a knowledge base and retrieval layer to the Operations Copilot. The agent retrieves relevant business evidence before composing a response and explicitly reports when the knowledge base does not contain enough information. Together AI generates the grounded response.

## Files

- `retrieval_agent.py` - document loading, embeddings, vector retrieval, and grounded response generation
- `business_documents.json` - synthetic, non-sensitive source documents
- `run_retrieval_demo.py` - compares answers with and without retrieval
- `test_retrieval_agent.py` - offline retrieval tests
- `requirements.txt` - LangChain dependencies for Together AI (`langchain-core`, `langchain-together`)
- `outputs/` - generated comparison and retrieval evidence files

## Offline run

The offline mode uses a deterministic local embedding implementation and in-memory vector store. It requires no API key or external service:

```text
C:\Users\CHRA\AppData\Local\Python\pythoncore-3.14-64\python.exe run_retrieval_demo.py --offline
```

This mode demonstrates the retrieval pipeline and is reproducible. It is not a measurement of commercial embedding-model quality.

## Together AI mode

Install the dependencies:

```text
C:\Users\CHRA\AppData\Local\Python\pythoncore-3.14-64\python.exe -m pip install -r requirements.txt
```

Set the key in the current terminal, then run:

```powershell
$env:TOGETHER_API_KEY = "your-key"
$env:TOGETHER_MODEL = "meta-llama/Llama-3.3-70B-Instruct-Turbo"
$env:TOGETHER_BASE_URL = "https://api.together.xyz/v1"
C:\Users\CHRA\AppData\Local\Python\pythoncore-3.14-64\python.exe run_retrieval_demo.py
```

The API key must remain outside source files, logs, screenshots, and repositories. The agent authenticates with `TOGETHER_API_KEY` through `langchain_together.ChatTogether`; no OpenAI key is used, and `TOGETHER_BASE_URL` is optional.

The retrieval index uses the local deterministic embedding implementation and in-memory vector store. The Together model `meta-llama/Llama-3.3-70B-Instruct-Turbo` is a chat/completions model, so it is used to compose the grounded answer rather than to create embeddings.

## Test

```text
C:\Users\CHRA\AppData\Local\Python\pythoncore-3.14-64\python.exe -m unittest -v
```

## Retrieval behavior

- Retrieved answers include document IDs and source titles.
- Results below the configured relevance threshold are treated as missing evidence.
- The agent does not invent a business answer when no relevant source is found.
- Source document content is synthetic for development and demonstration.
