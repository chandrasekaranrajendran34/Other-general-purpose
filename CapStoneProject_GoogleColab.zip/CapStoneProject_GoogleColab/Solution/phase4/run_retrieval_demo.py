"""Run Phase 4 retrieval and before/after demonstrations."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from retrieval_agent import (
    build_offline_agent,
    build_together_agent,
    load_documents,
    response_to_dict,
)


ROOT = Path(__file__).resolve().parent
QUESTIONS = [
    "Why is shipment SHP-1024 delayed?",
    "What policy should be used to assess stockout risk for SKU-1001?",
    "What is the latest weather forecast for the warehouse?",
]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--offline",
        action="store_true",
        help="Use deterministic local embeddings and an in-memory vector store.",
    )
    args = parser.parse_args()

    documents = load_documents(ROOT / "business_documents.json")
    agent = (
        build_offline_agent(documents)
        if args.offline
        else build_together_agent(documents)
    )
    results = []
    for question in QUESTIONS:
        without_retrieval = agent.answer(question, use_retrieval=False)
        with_retrieval = agent.answer(question, use_retrieval=True)
        result = {
            "question": question,
            "without_retrieval": response_to_dict(without_retrieval),
            "with_retrieval": response_to_dict(with_retrieval),
        }
        results.append(result)
        print(f"\nQuestion: {question}")
        print(f"Without retrieval: {without_retrieval.answer}")
        print(f"With retrieval: {with_retrieval.answer}")

    output_dir = ROOT / "outputs"
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "retrieval-comparison.json").write_text(
        json.dumps(results, indent=2), encoding="utf-8"
    )
    print("\nWrote outputs/retrieval-comparison.json")


if __name__ == "__main__":
    main()
