"""Phase 4 knowledge and retrieval implementation."""

from __future__ import annotations

import hashlib
import json
import math
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol


DEFAULT_TOGETHER_MODEL = "meta-llama/Llama-3.3-70B-Instruct-Turbo"
DEFAULT_TOGETHER_BASE_URL = "https://api.together.xyz/v1"


@dataclass(frozen=True)
class SourceDocument:
    document_id: str
    title: str
    content: str
    metadata: dict[str, str]


@dataclass(frozen=True)
class RetrievedDocument:
    document: SourceDocument
    score: float


@dataclass(frozen=True)
class RetrievalResponse:
    question: str
    answer: str
    sources: tuple[RetrievedDocument, ...]
    retrieval_used: bool
    escalated: bool


class EmbeddingModel(Protocol):
    def embed(self, text: str) -> list[float]:
        """Return a vector for text."""


class HashEmbeddings:
    """Small deterministic embedding model for offline development."""

    STOP_WORDS = {
        "a",
        "an",
        "and",
        "are",
        "be",
        "by",
        "for",
        "from",
        "has",
        "is",
        "of",
        "the",
        "to",
        "was",
        "what",
        "when",
        "where",
        "which",
        "why",
    }

    def __init__(self, dimensions: int = 2048) -> None:
        self.dimensions = dimensions

    def embed(self, text: str) -> list[float]:
        vector = [0.0] * self.dimensions
        tokens = self.tokenize(text)
        for token in tokens:
            digest = hashlib.sha256(token.encode("utf-8")).digest()
            index = int.from_bytes(digest[:4], "big") % self.dimensions
            vector[index] += 1.0
        magnitude = math.sqrt(sum(value * value for value in vector))
        return [value / magnitude for value in vector] if magnitude else vector

    @staticmethod
    def _normalize_token(token: str) -> str:
        if len(token) > 5 and token.endswith("ed"):
            return token[:-2]
        if len(token) > 4 and token.endswith("s"):
            return token[:-1]
        return token

    @classmethod
    def tokenize(cls, text: str) -> set[str]:
        tokens = {
            cls._normalize_token(token)
            for token in re.findall(r"[a-z0-9]+", text.lower())
        }
        return {token for token in tokens if token and token not in cls.STOP_WORDS}


class InMemoryVectorStore:
    """Vector store with cosine similarity for offline retrieval."""

    def __init__(self, embedding_model: EmbeddingModel) -> None:
        self.embedding_model = embedding_model
        self._items: list[tuple[SourceDocument, list[float], str]] = []

    def add_documents(self, documents: list[SourceDocument]) -> None:
        self._items.extend(
            (
                document,
                self.embedding_model.embed(
                    f"{document.document_id} {document.title} {document.content}"
                ),
                f"{document.document_id} {document.title} {document.content}",
            )
            for document in documents
        )

    def similarity_search(
        self, query: str, top_k: int = 3
    ) -> list[RetrievedDocument]:
        query_vector = self.embedding_model.embed(query)
        query_tokens = (
            self.embedding_model.tokenize(query)
            if isinstance(self.embedding_model, HashEmbeddings)
            else set()
        )
        ranked = []
        for document, vector, indexed_text in self._items:
            score = self._cosine(query_vector, vector)
            if query_tokens:
                overlap = query_tokens.intersection(
                    self.embedding_model.tokenize(indexed_text)
                )
                score += 0.15 * len(overlap) / len(query_tokens)
            ranked.append(RetrievedDocument(document=document, score=score))
        return sorted(ranked, key=lambda item: item.score, reverse=True)[:top_k]

    @staticmethod
    def _cosine(left: list[float], right: list[float]) -> float:
        return sum(a * b for a, b in zip(left, right))


def load_documents(path: Path) -> list[SourceDocument]:
    raw_documents = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(raw_documents, list):
        raise ValueError("Business document file must contain a JSON list.")
    return [
        SourceDocument(
            document_id=item["document_id"],
            title=item["title"],
            content=item["content"],
            metadata={
                key: str(value)
                for key, value in item.get("metadata", {}).items()
            },
        )
        for item in raw_documents
    ]


class AnswerGenerator(Protocol):
    def generate(self, question: str, evidence: str, source_list: str) -> str:
        """Compose a grounded answer."""


class TogetherAnswerGenerator:
    """Use the Together AI chat API (TOGETHER_API_KEY) for grounded answers."""

    def __init__(self, model: str | None = None) -> None:
        api_key = os.environ.get("TOGETHER_API_KEY")
        if not api_key:
            raise RuntimeError("TOGETHER_API_KEY is not set.")
        try:
            from langchain_together import ChatTogether
            from langchain_core.messages import HumanMessage, SystemMessage
        except ImportError as exc:
            raise RuntimeError(
                "Install requirements.txt before using Together AI."
            ) from exc
        self._chat = ChatTogether(
            model=model
            or os.environ.get("TOGETHER_MODEL", DEFAULT_TOGETHER_MODEL),
            temperature=0,
            together_api_key=api_key,
            base_url=os.environ.get(
                "TOGETHER_BASE_URL", DEFAULT_TOGETHER_BASE_URL
            ),
        )
        self._system_message = SystemMessage
        self._human_message = HumanMessage

    def generate(self, question: str, evidence: str, source_list: str) -> str:
        result = self._chat.invoke(
            [
                self._system_message(
                    content=(
                        "You are a safety-first inventory operations copilot. "
                        "Provide decision support only. Use only the supplied "
                        "evidence, do not invent facts, explain uncertainty, "
                        "and never perform or recommend an unapproved action."
                    )
                ),
                self._human_message(
                    content=(
                        f"Question: {question}\n\nEvidence: {evidence}\n\n"
                        f"Source IDs: {source_list}\n\n"
                        "Return a concise answer with Answer, Evidence, "
                        "Uncertainty, and Human next step sections."
                    )
                ),
            ]
        )
        if not isinstance(result.content, str):
            raise RuntimeError("Together AI returned a non-text response.")
        return result.content


class OfflineAnswerGenerator:
    def generate(self, question: str, evidence: str, source_list: str) -> str:
        del question
        return (
            f"Based on retrieved evidence: {evidence} "
            f"Sources: {source_list}. "
            "Confirm current timestamps and business context before acting."
        )


class RetrievalAgent:
    """Compose a grounded response from retrieved source documents."""

    def __init__(
        self,
        retriever: Any,
        answer_generator: AnswerGenerator,
        minimum_score: float = 0.25,
    ) -> None:
        self.retriever = retriever
        self.answer_generator = answer_generator
        self.minimum_score = minimum_score

    def answer(self, question: str, use_retrieval: bool = True) -> RetrievalResponse:
        if not use_retrieval:
            return RetrievalResponse(
                question=question,
                answer=(
                    "I cannot provide a grounded operations answer without "
                    "retrieving approved business evidence."
                ),
                sources=(),
                retrieval_used=False,
                escalated=True,
            )

        candidates = self.retriever.similarity_search(question, top_k=3)
        sources = tuple(
            item for item in candidates if item.score >= self.minimum_score
        )
        if not sources:
            return RetrievalResponse(
                question=question,
                answer=(
                    "I could not find sufficiently relevant approved evidence "
                    "for this question. I will not guess. Please provide a "
                    "specific identifier or escalate to a human analyst."
                ),
                sources=(),
                retrieval_used=True,
                escalated=True,
            )

        evidence = " ".join(
            f"{item.document.title}: {item.document.content}" for item in sources
        )
        source_list = ", ".join(
            item.document.document_id for item in sources
        )
        return RetrievalResponse(
            question=question,
            answer=self.answer_generator.generate(
                question, evidence, source_list
            ),
            sources=sources,
            retrieval_used=True,
            escalated=False,
        )


def build_offline_agent(documents: list[SourceDocument]) -> RetrievalAgent:
    store = InMemoryVectorStore(HashEmbeddings())
    store.add_documents(documents)
    return RetrievalAgent(store, OfflineAnswerGenerator())


def build_together_agent(documents: list[SourceDocument]) -> RetrievalAgent:
    store = InMemoryVectorStore(HashEmbeddings())
    store.add_documents(documents)
    return RetrievalAgent(store, TogetherAnswerGenerator())


def response_to_dict(response: RetrievalResponse) -> dict[str, Any]:
    return {
        "question": response.question,
        "answer": response.answer,
        "retrieval_used": response.retrieval_used,
        "escalated": response.escalated,
        "sources": [
            {
                "document_id": item.document.document_id,
                "title": item.document.title,
                "score": round(item.score, 4),
            }
            for item in response.sources
        ],
    }
