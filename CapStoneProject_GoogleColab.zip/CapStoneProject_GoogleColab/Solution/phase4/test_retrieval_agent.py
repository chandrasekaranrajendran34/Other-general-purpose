"""Offline tests for Phase 4 retrieval."""

import unittest
from pathlib import Path

from retrieval_agent import (
    HashEmbeddings,
    InMemoryVectorStore,
    RetrievalAgent,
    build_offline_agent,
    load_documents,
)


class RetrievalAgentTests(unittest.TestCase):
    def setUp(self) -> None:
        self.root = Path(__file__).resolve().parent
        self.documents = load_documents(self.root / "business_documents.json")
        self.agent = build_offline_agent(self.documents)

    def test_documents_load(self) -> None:
        self.assertEqual(len(self.documents), 5)
        self.assertEqual(self.documents[0].document_id, "INV-POL-001")

    def test_semantic_retrieval_returns_shipment_evidence(self) -> None:
        response = self.agent.answer("Why was the shipment delayed?")
        self.assertTrue(response.retrieval_used)
        self.assertTrue(response.sources)
        self.assertIn("SHP-REC-1024", {item.document.document_id for item in response.sources})

    def test_grounded_response_contains_source_id(self) -> None:
        response = self.agent.answer("What caused SHP-1024 to be delayed?")
        self.assertIn("SHP-REC-1024", response.answer)
        self.assertIn("carrier capacity", response.answer)

    def test_missing_information_escalates(self) -> None:
        response = self.agent.answer("What is the latest weather forecast?")
        self.assertTrue(response.escalated)
        self.assertIn("could not find", response.answer)

    def test_without_retrieval_does_not_guess(self) -> None:
        response = self.agent.answer("Why is SHP-1024 delayed?", use_retrieval=False)
        self.assertFalse(response.retrieval_used)
        self.assertTrue(response.escalated)

    def test_hash_embeddings_are_normalized(self) -> None:
        vector = HashEmbeddings().embed("inventory stock risk")
        magnitude = sum(value * value for value in vector) ** 0.5
        self.assertAlmostEqual(magnitude, 1.0)

    def test_in_memory_store_ranks_relevant_document(self) -> None:
        store = InMemoryVectorStore(HashEmbeddings())
        store.add_documents(self.documents)
        results = store.similarity_search("carrier shipment delay", top_k=1)
        self.assertEqual(results[0].document.document_id, "SHP-REC-1024")


if __name__ == "__main__":
    unittest.main()
