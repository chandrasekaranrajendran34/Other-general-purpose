"""Generate the deterministic Phase 9 evaluation report."""

from pathlib import Path

from evaluation_harness import EvaluationHarness, write_report


def main() -> None:
    harness = EvaluationHarness()
    results = harness.run()
    report = harness.report(results)
    json_path, md_path = write_report(Path(__file__).with_name("reports"), report)
    print(f"Scenarios: {report['metrics']['scenarios']}")
    print(f"Accuracy: {report['metrics']['accuracy']:.1%}")
    print(f"Wrote {json_path}")
    print(f"Wrote {md_path}")


if __name__ == "__main__":
    main()
