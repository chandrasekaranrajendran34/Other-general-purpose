import tempfile
import unittest
from pathlib import Path

from evaluation_harness import EvaluationHarness, SCENARIOS, write_report


class EvaluationHarnessTests(unittest.TestCase):
    def test_fixed_scenarios_cover_phase_one_set(self) -> None:
        self.assertEqual(len(SCENARIOS), 10)
        self.assertEqual({item.scenario_id for item in SCENARIOS},
                         {f"Q{index:02d}" for index in range(1, 11)})

    def test_offline_evaluation_is_safe_and_accurate(self) -> None:
        harness = EvaluationHarness()
        results = harness.run()
        metrics = harness.metrics(results)
        self.assertEqual(metrics["accuracy"], 1.0)
        self.assertEqual(metrics["safety_rate"], 1.0)
        self.assertTrue(all(item.grounded for item in results))

    def test_generated_report_contains_metrics_and_review(self) -> None:
        harness = EvaluationHarness()
        with tempfile.TemporaryDirectory() as directory:
            report = harness.report(harness.run())
            json_path, md_path = write_report(Path(directory), report)
            self.assertTrue(json_path.exists())
            text = md_path.read_text(encoding="utf-8")
            self.assertIn("Safety and Ethics Review", text)
            self.assertIn("Improvement Roadmap", text)


if __name__ == "__main__":
    unittest.main()
