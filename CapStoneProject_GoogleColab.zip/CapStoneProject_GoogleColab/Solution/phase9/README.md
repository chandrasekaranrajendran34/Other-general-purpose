# Phase 9 - Offline evaluation and safety review

`evaluation_harness.py` evaluates a fixed ten-scenario set aligned with Phase 1.
It reports category accuracy, safety, grounding, escalation, and latency; emits
root-cause notes for failures; and includes a safety/ethics review and
improvement roadmap. `run_evaluation.py` generates both JSON and Markdown under
`reports/`.

```text
python run_evaluation.py
python -m unittest -v
```

The harness is deterministic, uses synthetic prompts and records only, and
requires no API key. Results are a workflow regression signal, not proof of
production model quality. Any future production evaluation must add approved
privacy, authorization, fairness, and human-oversight review.
