# Phase 7 - Feedback and bounded adaptation

Feedback is stored as append-only JSONL metadata: hashed interaction ID, rating,
controlled issue label, and timestamp. Prompt text, business identifiers, and
responses are not persisted. `FeedbackAdapter` changes only presentation
preferences (concise versus evidence-first); it cannot enable writes, bypass
clarification, or weaken refusal rules.

```text
python run_demo.py
python -m unittest -v
```

Synthetic data and the standard library are sufficient. Feedback is treated as
a signal, not as permission to take an operational action.
