"""Show deterministic response adaptation before and after feedback."""

import tempfile
from pathlib import Path

from feedback_adaptation import FeedbackAdapter, FeedbackAgent, FeedbackStore, response_to_dict


def main() -> None:
    with tempfile.TemporaryDirectory() as directory:
        store = FeedbackStore(Path(directory) / "feedback.jsonl")
        agent = FeedbackAgent(FeedbackAdapter(store))
        question = "Why is shipment SHP-1024 delayed?"
        before = agent.answer(question)
        print("Before feedback:", response_to_dict(before))
        store.add(before.interaction_id, 2, "missing_evidence")
        after = agent.answer(question)
        print("After feedback:", response_to_dict(after))


if __name__ == "__main__":
    main()
