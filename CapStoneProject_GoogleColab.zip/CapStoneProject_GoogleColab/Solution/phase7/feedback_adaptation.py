"""Phase 7: privacy-preserving feedback storage and bounded adaptation."""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class FeedbackEvent:
    interaction_id: str
    rating: int
    issue: str
    timestamp_utc: str


@dataclass
class AdaptivePolicy:
    """Small, auditable policy; feedback never changes safety boundaries."""

    response_style: str = "balanced"
    evidence_detail: int = 1
    clarification_bias: bool = True


class FeedbackStore:
    """Append-only JSONL store containing no raw prompt or response text."""

    VALID_ISSUES = {"none", "too_verbose", "missing_evidence", "incorrect", "unsafe"}

    def __init__(self, path: Path) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def add(self, interaction_id: str, rating: int, issue: str = "none") -> FeedbackEvent:
        if rating not in range(1, 6):
            raise ValueError("rating must be an integer from 1 to 5")
        if issue not in self.VALID_ISSUES:
            raise ValueError(f"issue must be one of {sorted(self.VALID_ISSUES)}")
        safe_id = interaction_id
        if not re.fullmatch(r"[0-9a-f]{16,64}", safe_id, re.IGNORECASE):
            safe_id = hashlib.sha256(safe_id.encode("utf-8")).hexdigest()[:16]
        event = FeedbackEvent(
            interaction_id=safe_id,
            rating=rating,
            issue=issue,
            timestamp_utc=datetime.now(timezone.utc).isoformat(),
        )
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(asdict(event)) + "\n")
        return event

    def read(self) -> list[FeedbackEvent]:
        if not self.path.exists():
            return []
        events: list[FeedbackEvent] = []
        for line in self.path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                events.append(FeedbackEvent(**json.loads(line)))
        return events


def interaction_id(question: str) -> str:
    return hashlib.sha256(question.encode("utf-8")).hexdigest()[:16]


class FeedbackAdapter:
    """Apply aggregate feedback conservatively and deterministically."""

    def __init__(self, store: FeedbackStore, policy: AdaptivePolicy | None = None):
        self.store = store
        self.policy = policy or AdaptivePolicy()

    def learn(self) -> AdaptivePolicy:
        events = self.store.read()
        if not events:
            return self.policy
        issue_counts: dict[str, int] = {}
        for event in events:
            issue_counts[event.issue] = issue_counts.get(event.issue, 0) + 1
        if issue_counts.get("too_verbose", 0) > issue_counts.get("missing_evidence", 0):
            self.policy.response_style = "concise"
            self.policy.evidence_detail = 1
        if issue_counts.get("missing_evidence", 0) >= 1:
            self.policy.response_style = "evidence_first"
            self.policy.evidence_detail = 2
        if issue_counts.get("unsafe", 0) >= 1 or issue_counts.get("incorrect", 0) >= 2:
            self.policy.clarification_bias = True
        return self.policy


@dataclass(frozen=True)
class AdaptiveResponse:
    interaction_id: str
    text: str
    policy: AdaptivePolicy


class FeedbackAgent:
    """Synthetic response generator used to demonstrate before/after behavior."""

    def __init__(self, adapter: FeedbackAdapter):
        self.adapter = adapter

    def answer(self, question: str) -> AdaptiveResponse:
        policy = self.adapter.learn()
        iid = interaction_id(question)
        base = "SHP-1024 is delayed due to a carrier capacity constraint."
        if policy.response_style == "concise":
            text = base
        elif policy.response_style == "evidence_first":
            text = (base + " Evidence: the approved shipment record was last updated "
                    "2026-09-20. Uncertainty: confirm current status before acting.")
        else:
            text = (base + " Confirm the timestamp and review the approved record "
                    "with a human analyst before any operational decision.")
        return AdaptiveResponse(iid, text, AdaptivePolicy(**asdict(policy)))


def response_to_dict(response: AdaptiveResponse) -> dict[str, Any]:
    return {
        "interaction_id": response.interaction_id,
        "text": response.text,
        "policy": asdict(response.policy),
    }
