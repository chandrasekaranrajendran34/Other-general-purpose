import json
import tempfile
import unittest
from pathlib import Path

from feedback_adaptation import (
    FeedbackAdapter, FeedbackAgent, FeedbackStore, interaction_id,
)


class FeedbackAdaptationTests(unittest.TestCase):
    def test_feedback_is_stored_without_prompt_text(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "feedback.jsonl"
            store = FeedbackStore(path)
            store.add("abc123", 4)
            raw = path.read_text(encoding="utf-8")
            self.assertNotIn("shipment", raw)
            self.assertEqual(len(store.read()), 1)

    def test_missing_evidence_feedback_changes_output(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store = FeedbackStore(Path(directory) / "feedback.jsonl")
            agent = FeedbackAgent(FeedbackAdapter(store))
            before = agent.answer("Why is shipment SHP-1024 delayed?")
            store.add(before.interaction_id, 2, "missing_evidence")
            after = agent.answer("Why is shipment SHP-1024 delayed?")
            self.assertEqual(after.policy.response_style, "evidence_first")
            self.assertGreater(len(after.text), len(before.text))

    def test_too_verbose_feedback_requests_concise_response(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store = FeedbackStore(Path(directory) / "feedback.jsonl")
            adapter = FeedbackAdapter(store)
            agent = FeedbackAgent(adapter)
            before = agent.answer("Why is shipment SHP-1024 delayed?")
            store.add(interaction_id("q"), 2, "too_verbose")
            after = agent.answer("Why is shipment SHP-1024 delayed?")
            self.assertEqual(after.policy.response_style, "concise")
            self.assertLess(len(after.text), len(before.text))

    def test_invalid_feedback_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store = FeedbackStore(Path(directory) / "feedback.jsonl")
            with self.assertRaises(ValueError):
                store.add("id", 0)
            with self.assertRaises(ValueError):
                store.add("id", 5, "free_text")


if __name__ == "__main__":
    unittest.main()
