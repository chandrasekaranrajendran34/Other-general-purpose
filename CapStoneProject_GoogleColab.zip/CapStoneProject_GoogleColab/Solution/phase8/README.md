# Phase 8 - Package and deployment readiness

`service.py` exposes a small application boundary suitable for a CLI or a
future HTTP adapter. It includes a health check, graceful invalid/internal
failure responses, latency and error metrics, and a metadata-only JSONL logger.
Logs contain a request hash and lengths, never prompts, responses, identifiers,
emails, phone numbers, or records.

Local run and tests require only Python 3.14:

```text
python run_local.py
python -m unittest -v
```

`requirements.txt` is intentionally empty of third-party dependencies.
`pyproject.toml` documents the package metadata; deployment must keep
`writes_enabled=false` until a separately approved, authenticated workflow
exists. Synthetic records are used for all examples.
