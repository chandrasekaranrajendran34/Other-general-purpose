"""Phase 8: small deployment-ready offline service boundary.

This module has no web framework dependency.  It provides the same boundary a
CLI or HTTP adapter can call: health, request handling, safe structured logs,
latency/error metrics, and graceful failure responses.
"""

from __future__ import annotations

import hashlib
import json
import re
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable


@dataclass(frozen=True)
class ServiceResponse:
    ok: bool
    category: str
    text: str
    latency_ms: float
    error_code: str | None = None


class SafeEventLogger:
    """Persist operational metadata only, with defense-in-depth redaction."""

    EMAIL = re.compile(r"[\w.+-]+@[\w.-]+\.\w+")
    PHONE = re.compile(r"(?<!\d)(?:\+?\d[\d ()-]{7,}\d)(?!\d)")

    def __init__(self, path: Path) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def log(self, question: str, response: ServiceResponse) -> None:
        event = {
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            "request_sha256": hashlib.sha256(question.encode("utf-8")).hexdigest(),
            "request_length": len(question),
            "ok": response.ok,
            "category": response.category,
            "latency_ms": round(response.latency_ms, 3),
            "error_code": response.error_code,
        }
        # Serialize and scan the final payload so future fields cannot
        # accidentally introduce an email address or telephone number.
        payload = self.EMAIL.sub("[redacted-email]", json.dumps(event))
        payload = self.PHONE.sub("[redacted-phone]", payload)
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(payload + "\n")


class InventoryOperationsService:
    """Offline service façade with deterministic synthetic responses."""

    def __init__(
        self,
        logger: SafeEventLogger | None = None,
        responder: Callable[[str], tuple[str, str]] | None = None,
    ) -> None:
        self.logger = logger
        self.responder = responder or self._respond
        self.total_requests = 0
        self.error_requests = 0
        self.total_latency_ms = 0.0

    def health(self) -> dict[str, str]:
        return {"status": "ok", "mode": "offline", "writes_enabled": "false"}

    def handle(self, question: str) -> ServiceResponse:
        started = time.perf_counter()
        self.total_requests += 1
        try:
            if not isinstance(question, str) or not question.strip():
                raise ValueError("empty_request")
            category, text = self.responder(question)
            response = ServiceResponse(True, category, text,
                                       (time.perf_counter() - started) * 1000)
        except ValueError as exc:
            self.error_requests += 1
            response = ServiceResponse(
                False, "invalid_input", "Please provide a non-empty operations question.",
                (time.perf_counter() - started) * 1000, str(exc),
            )
        except Exception:
            self.error_requests += 1
            response = ServiceResponse(
                False, "service_error",
                "The copilot could not complete this request. Please retry or "
                "escalate to a human analyst.",
                (time.perf_counter() - started) * 1000, "internal_error",
            )
        self.total_latency_ms += response.latency_ms
        if self.logger:
            self.logger.log(question if isinstance(question, str) else "", response)
        return response

    def metrics(self) -> dict[str, float | int]:
        return {
            "requests": self.total_requests,
            "errors": self.error_requests,
            "error_rate": (self.error_requests / self.total_requests
                           if self.total_requests else 0.0),
            "average_latency_ms": (self.total_latency_ms / self.total_requests
                                  if self.total_requests else 0.0),
        }

    @staticmethod
    def _respond(question: str) -> tuple[str, str]:
        normalized = " ".join(question.lower().split())
        if re.search(r"\b(update|delete|remove|place|order|notify|send|trigger)\b",
                     normalized):
            return ("unsafe_action",
                    "I cannot modify records, place orders, send notifications, "
                    "or trigger actions. Use an approved human workflow.")
        shipment = re.search(r"\bSHP-\d{4}\b", question, re.IGNORECASE)
        if shipment:
            return ("shipment_status",
                    f"{shipment.group(0).upper()} is delayed in the synthetic "
                    "approved record; reason: carrier capacity constraint.")
        if "inventory" in normalized or "stockout" in normalized:
            return ("inventory_status",
                    "Synthetic records mark SKU-1001 and SKU-1003 at risk. "
                    "Confirm current demand and timestamps.")
        return ("clarification",
                "Please provide a shipment or product identifier. I will not guess.")


# A concise alias for adapters that prefer an application-style name.
Application = InventoryOperationsService


def response_to_dict(response: ServiceResponse) -> dict[str, Any]:
    return asdict(response)
