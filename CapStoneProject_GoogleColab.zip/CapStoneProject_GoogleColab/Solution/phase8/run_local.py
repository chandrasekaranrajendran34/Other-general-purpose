"""Run the Phase 8 service locally without a web server or API key."""

import json
from pathlib import Path

from service import InventoryOperationsService, SafeEventLogger


def main() -> None:
    log_path = Path(__file__).with_name("local-events.jsonl")
    service = InventoryOperationsService(SafeEventLogger(log_path))
    print("Health:", service.health())
    for question in ("Why is shipment SHP-1024 delayed?",
                     "Place an order for SKU-1001",
                     ""):
        print(json.dumps({"question": question, "response": service.handle(question).__dict__},
                         default=str))
    print("Metrics:", service.metrics())
    print(f"Metadata log: {log_path.name}")


if __name__ == "__main__":
    main()
