import json
import tempfile
import unittest
from pathlib import Path

from service import InventoryOperationsService, SafeEventLogger


class ServiceTests(unittest.TestCase):
    def test_health_is_read_only(self) -> None:
        service = InventoryOperationsService()
        self.assertEqual(service.health()["status"], "ok")
        self.assertEqual(service.health()["writes_enabled"], "false")

    def test_success_captures_latency_and_metrics(self) -> None:
        service = InventoryOperationsService()
        response = service.handle("Why is shipment SHP-1024 delayed?")
        self.assertTrue(response.ok)
        self.assertGreaterEqual(response.latency_ms, 0)
        self.assertEqual(service.metrics()["requests"], 1)

    def test_graceful_failure_does_not_leak_exception(self) -> None:
        def broken(_: str) -> tuple[str, str]:
            raise RuntimeError("secret internal detail")
        service = InventoryOperationsService(responder=broken)
        response = service.handle("hello")
        self.assertFalse(response.ok)
        self.assertNotIn("secret", response.text)
        self.assertEqual(response.error_code, "internal_error")

    def test_pii_safe_log_has_metadata_only(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "events.jsonl"
            service = InventoryOperationsService(SafeEventLogger(path))
            question = "Email alex@example.com or call +1 555 010 2222 about SHP-1024"
            service.handle(question)
            event = json.loads(path.read_text(encoding="utf-8"))
            self.assertNotIn("alex@example.com", path.read_text(encoding="utf-8"))
            self.assertNotIn("555 010 2222", path.read_text(encoding="utf-8"))
            self.assertIn("request_sha256", event)
            self.assertNotIn("text", event)

    def test_unsafe_request_is_refused(self) -> None:
        response = InventoryOperationsService().handle("Place an order for SKU-1001")
        self.assertEqual(response.category, "unsafe_action")


if __name__ == "__main__":
    unittest.main()
