# Running the Capstone in Google Colab - Step by Step

This folder is a Colab-ready copy of the Inventory Operations Copilot capstone
(Phase 1 to Phase 9).


## What changed versus the original project

Every phase's business logic, prompts, tests and data files are **unchanged**.
Only the following was added or adjusted:

| File | Change |
| --- | --- |
| `colab_setup.py` | **New.** Project-root discovery, dependency install, Together AI credential loading from Colab Secrets, and a phase runner that sets the correct working directory. |
| `run_all_phases.py` | **New.** One-command execution of Phase 1 to Phase 9 plus all unit tests. |
| `Capstone_Colab.ipynb` | **New.** The notebook you actually run in Colab. |
| `requirements-colab.txt` | **New.** The two packages Phase 3 and Phase 4 need. |
| `Solution/phase8/pyproject.toml` | `requires-python` relaxed from `>=3.14` to `>=3.10` so it installs on the Colab runtime (Python 3.12). |

All source files are already valid Python 3.10+, so no syntax changes were required.

---

## Step 1 - Get this folder into Colab

Choose one option.

**Option A - Upload a ZIP (fastest)**

1. In Windows Explorer, right-click `CapStoneProject_GoogleColab`.
2. Choose **Send to > Compressed (zipped) folder**.
3. Open <https://colab.research.google.com> and upload `Capstone_Colab.ipynb`
   (**File > Upload notebook**).
4. Run the *Option A* cell and pick the ZIP when the file chooser appears.

**Option B - Google Drive**

1. Copy the `CapStoneProject_GoogleColab` folder into *My Drive*.
2. In Drive, right-click `Capstone_Colab.ipynb` and choose **Open with > Google Colaboratory**.
3. Run the *Option B* cell and approve the Drive mount prompt.

**Option C - GitHub**

1. Push this folder to a repository.
2. In Colab use **File > Open notebook > GitHub** and select `Capstone_Colab.ipynb`.
3. Run the *Option C* cell after editing the clone URL.

## Step 2 - Bootstrap

Run the Step 2 cell. It locates `colab_setup.py`, adds the project root to `sys.path`,
changes the working directory, and prints the runtime details.

## Step 3 - Install dependencies

Run `cs.install_requirements()`. This installs `langchain-core` and `langchain-together`.
Skip it only if you intend to run every phase offline.

## Step 4 - Add your Together AI key (recommended: Colab Secrets)

1. Click the **key icon** in the Colab left sidebar.
2. **Add new secret**, name it exactly `TOGETHER_API_KEY`.
3. Paste your key from <https://api.together.ai/settings/api-keys> as the value.
4. Turn on **Notebook access**.
5. Run the Step 4 cell.

The helper also accepts a hidden `getpass` prompt if no secret is found.
The key is never printed and never written to disk.

Defaults applied:

```
TOGETHER_MODEL    = meta-llama/Llama-3.3-70B-Instruct-Turbo
TOGETHER_BASE_URL = https://api.together.xyz/v1
```

## Step 5 - Run the phases

Run the phase cells top to bottom. Each phase cell calls:

```python
cs.run_phase(<phase>, '<script>.py', [args], save_as='<file>')   # demo
cs.run_phase_tests(<phase>)                                      # unit tests
```

Console output for every run is saved to `Solution/phase<N>/outputs/`.

| Phase | Demo command | Needs key |
| --- | --- | --- |
| 1 | documentation + `test-scenarios.yaml` | no |
| 2 | `run_demo.py` | no |
| 3 | `run_comparison.py [--offline]` | live mode only |
| 4 | `run_retrieval_demo.py [--offline]` | live mode only |
| 5 | `run_demo.py` | no |
| 6 | `run_demo.py` | no |
| 7 | `run_demo.py` | no |
| 8 | `run_local.py` | no |
| 9 | `run_evaluation.py` | no |

## Step 6 - Or run everything at once

```python
!python run_all_phases.py --offline   # no network, no key
!python run_all_phases.py --live      # Phase 3 and 4 call Together AI
```

Add `--skip-tests` to run only the demos.

## Step 7 - Download the results

```python
archive = cs.zip_outputs()
from google.colab import files
files.download(str(archive))
```

This bundles every `outputs/`, `logs/` and `reports/` folder into
`capstone_outputs.zip`.

---

## Running this copy locally (optional)

It still works on a normal machine:

```bash
python run_all_phases.py --offline
```

Offline mode never touches the network, so it succeeds even behind the corporate proxy.

## Troubleshooting

| Symptom | Cause | Fix |
| --- | --- | --- |
| `colab_setup.py not found` | Step 1 did not place the project under `/content` | Re-run Step 1, then Step 2 |
| `Could not find the capstone root` | Wrong explicit path | `cs.bootstrap('/content/CapStoneProject_GoogleColab')` |
| `TOGETHER_API_KEY is not set` | Secret missing or notebook access off | Re-run Step 4 and check the Secrets toggle |
| `ModuleNotFoundError: langchain_together` | Step 3 skipped | `cs.install_requirements()` |
| `CERTIFICATE_VERIFY_FAILED` | Running locally behind the proxy, not in Colab | Use Colab, or run with `--offline` |
| HTTP `401` from Together AI | Invalid or expired key | Regenerate the key and update the secret |
| Colab session disconnects mid-run | Idle timeout | Re-run Step 2 to Step 4, then resume |
