# LangChain AI Operations Copilot

**Assignment track:** Track A — Framework-Based (LangChain)
**Scenario:** Scenario 1 — Business Operations: AI Operations Copilot (Decision Support Only)
**LLM provider:** Together AI (`TOGETHER_API_KEY`). No OpenAI key is used anywhere.

> **New here? Read these two sections first:**
> - [Section 11 — How the Nine Phases Connect at Runtime](#11-how-the-nine-phases-connect-at-runtime) explains how the separate phase folders form one working product.
> - [Section 12 — Step-by-Step Execution Guide](#12-step-by-step-execution-guide-for-anyone) is a copy-paste guide that takes you from a blank machine to a complete, validated submission. No prior experience assumed.

> **Running in Google Colab?** This copy of the project is Colab-ready. Open
> [`Capstone_Colab.ipynb`](Capstone_Colab.ipynb) in Colab and follow
> [`COLAB_GUIDE.md`](COLAB_GUIDE.md). Use Colab when a corporate TLS-inspecting proxy
> blocks the Together AI endpoint with `CERTIFICATE_VERIFY_FAILED`.

## 1. Project Objective

Build a LangChain-based AI Operations Copilot for a realistic business workflow. The agent provides decision support only.

The agent must:

- Answer business-operation questions using available documents and data.
- Explain its reasoning and uncertainty.
- Refuse requests to modify data or trigger actions.
- Escalate uncertain or sensitive cases to a human analyst.
- Avoid storing sensitive business data in logs.
- Demonstrate improvement through evidence across Phases 1-9.

## 2. Recommended Project Scope

The recommended workflow is an **Inventory Operations Copilot** that helps operations analysts investigate stock levels, delayed shipments, reorder risks, and supplier performance.

Example user questions:

1. Which products are at risk of stockout this week?
2. Why was shipment `SHP-1024` delayed?
3. Which suppliers have the highest recent delay rate?
4. What information supports this recommendation?
5. Can you update the reorder quantity?

The last question must be refused because the agent is decision-support only.

## 3. Proposed LangChain Architecture

```text
User
  |
  v
LangChain Agent
  |- Safety and intent check
  |- Prompt and LLM
  |- Retrieval system
  |- Read-only business tools
  |- Planning and memory
  |- Feedback handling
  `- Logging, tracing, and evaluation
  |
  v
Answer, uncertainty explanation, or human escalation
```

Suggested components:

- Python 3.10+
- LangChain (`langchain-core`, `langchain-together`)
- Together AI as the LLM provider, authenticated with `TOGETHER_API_KEY`
- Vector retrieval (a deterministic in-memory store is used here so the pipeline is reproducible offline; Chroma or FAISS can be swapped in)
- Typed tool schemas for read-only tools
- JSON files for feedback and non-sensitive memory
- Environment variables for API keys
- Metadata-only local tracing (`SafeLLMLogger`, `SafeEventLogger`)

> For how these components are actually wired together into one request pipeline, see [Section 11](#11-how-the-nine-phases-connect-at-runtime). For how to run them, see [Section 12](#12-step-by-step-execution-guide-for-anyone).

## 4. Phase-by-Phase Execution Plan

### Phase 1: Problem Framing and Success Definition

**Coding:** Not required, but optional.

**Goals:**

- Define the user, workflow, boundaries, and evaluation criteria before coding.
- Select the business domain and workflow.
- Define the primary user persona.
- Document the current business problem.
- Define inputs, outputs, constraints, and assumptions.
- Write 3-5 realistic user questions.
- Define measurable success criteria.
- List failure cases and edge scenarios.

**Deliverables:**

- Problem framing document of 1-2 pages
- User persona
- Workflow diagram
- Success metrics
- Initial test-question set
- Risk and failure-case list

### Phase 2: Basic Working Agent

**Coding:** Required.

**Goals:**

Create a simple baseline before using an LLM or retrieval.

**Tasks:**

- Create a Python CLI or notebook agent.
- Accept user input.
- Generate responses using rules or templates.
- Log sample interactions safely.
- Demonstrate at least two limitations.

Expected limitations may include:

- Inability to understand varied wording.
- Inability to answer questions outside predefined rules.
- Inability to cite supporting business information.
- Failure on incomplete or ambiguous input.

**Deliverables:**

- Baseline Python agent
- Sample interaction logs
- Baseline limitation analysis

### Phase 3: LLM Integration and Prompt Comparison

**Coding:** Required.

**Goals:**

Improve response quality and prove the improvement with controlled testing.

**Tasks:**

- Integrate an LLM using LangChain.
- Create 2-3 prompt variants.
- Run all prompts against the same test set.
- Compare response quality, safety, clarity, and uncertainty handling.
- Select and justify the default prompt.

Required comparison table:

| Prompt | Output | Improvements | Problems |
| --- | --- | --- | --- |
| Basic prompt | Response | Faster setup | May guess |
| Structured prompt | Response | Better format | More verbose |
| Safety-focused prompt | Response | Better refusal behavior | May over-refuse |

**Deliverables:**

- Versioned prompts
- Prompt comparison table
- Failure analysis
- Selected default prompt with justification

### Phase 4: Knowledge and Retrieval

**Coding:** Required.

**Goals:**

Allow the agent to answer using business documents or datasets.

**Tasks:**

- Prepare synthetic or non-sensitive business documents and data.
- Chunk the documents.
- Generate embeddings.
- Store vectors in Chroma or FAISS.
- Retrieve relevant information for each question.
- Include retrieved evidence in responses.
- Handle insufficient or missing information explicitly.

**Deliverables:**

- Source documents or datasets
- Retrieval pipeline
- Retrieval examples
- Before-versus-after comparison
- Missing-information test case

### Phase 5: Read-Only Tool Usage

**Coding:** Required.

**Goals:**

Allow the agent to call tools while preventing unsafe actions.

Suggested tools:

1. `search_inventory(product_id)`
2. `get_shipment_status(shipment_id)`
3. `get_supplier_metrics(supplier_id)`
4. `search_business_documents(query)`

All tools must be read-only.

**Tasks:**

- Define typed tool schemas.
- Implement tool-selection logic.
- Demonstrate correct tool selection.
- Demonstrate an incorrect or failed tool call.
- Add validation, error handling, and loop prevention.
- Refuse update, delete, and trigger requests.

**Deliverables:**

- Tool definitions
- Tool execution logs
- Successful tool-call demonstration
- Failed tool-call demonstration
- Safety refusal demonstration

### Phase 6: Planning, Memory, and Context

**Coding:** Required.

**Goals:**

Improve multi-step and multi-turn conversations.

**Tasks:**

- Add planning or task-decomposition logic.
- Add short-term conversation memory.
- Decide what information may be retained.
- Define memory reset behavior.
- Test follow-up questions across multiple turns.

Do not store sensitive business data in memory or logs. Store only permitted, non-sensitive context such as user preferences, conversation topic, or feedback category.

**Deliverables:**

- Planning flow
- Memory policy
- Reset and retention rules
- Multi-turn test results

### Phase 7: Adaptive Behaviour

**Coding:** Required.

**Goals:**

Use feedback to improve future responses.

**Tasks:**

- Collect feedback such as helpful or not helpful.
- Store feedback safely.
- Adjust response style or retrieval behavior.
- Compare behavior before and after feedback.
- Explain what changed and why.

Example:

- Feedback: "Always show the evidence supporting the recommendation."
- Adaptation: Future responses include a concise evidence section and confidence level.

**Deliverables:**

- Feedback mechanism
- Feedback storage
- Before-and-after examples
- Adaptation explanation

### Phase 8: Deployment Readiness

**Coding:** Required.

**Goals:**

Make the project reproducible and demonstrate operational reliability.

**Tasks:**

- Package the application.
- Add dependency management.
- Create setup instructions.
- Deploy locally or to a cloud environment.
- Capture latency and error information.
- Demonstrate graceful failure.
- Document deployment assumptions and limitations.

**Deliverables:**

- `README`
- Dependency file
- Configuration instructions
- Deployment demo
- Error and latency logs
- Graceful-failure example

### Phase 9: Evaluation and Engineering Review

**Coding:** Required.

**Goals:**

Measure quality, identify root causes, and propose improvements.

**Tasks:**

- Create a fixed evaluation dataset.
- Test normal, ambiguous, unsupported, unsafe, and missing-data questions.
- Measure quality and consistency.
- Analyze at least one failure using root-cause analysis.
- Review safety, privacy, and ethical behavior.
- Propose future improvements.

Suggested metrics:

- Answer correctness
- Retrieval relevance
- Citation or evidence correctness
- Prompt consistency
- Tool-selection accuracy
- Unsafe-request refusal rate
- Uncertainty-disclosure rate
- Human-escalation accuracy
- Average response latency
- Runtime error rate

**Deliverables:**

- Evaluation prompts and scenarios
- Metrics table
- Failure root-cause analysis
- Before-and-after fix evidence
- Safety and ethics review
- Improvement roadmap

## 5. Final Submission Package

The final submission should contain:

1. Working LangChain AI agent
2. Problem Framing Document
3. Demo Script with 3-5 forced interactions
4. Evaluation Report
5. Engineering and Product Justification
6. Evidence for retrieval, tools, memory, and adaptation
7. Safety enforcement demonstration
8. Prompt comparison table
9. Setup and deployment instructions
10. Logs, screenshots, or tables proving behavior

## 6. Required Demo Interactions

The demo should include:

1. A normal business question answered using retrieval.
2. A multi-step question requiring more than one tool.
3. A question where relevant information is missing.
4. An unsafe request to modify data that is refused.
5. An ambiguous or uncertain question that triggers an explanation or human escalation.

## 7. Key Decisions to Finalize

Before implementation, finalize:

- Exact business industry and workflow
- Synthetic dataset or documents
- LLM provider
- Local deployment or cloud deployment
- Specific read-only tools
- Evaluation metrics and target thresholds
- Memory retention policy

## 8. Safety and Security Requirements

- Never allow the agent to modify, delete, or trigger business actions.
- Explain uncertainty instead of guessing.
- Escalate unresolved cases to a human analyst.
- Do not store sensitive business data in logs or memory.
- Keep API keys in environment variables or secure configuration.
- Never hard-code API keys in notebooks, source files, screenshots, or public repositories.
- If an API key is exposed, rotate it immediately.

## 9. Project Approach

Build the capstone like an industry project:

1. Define success.
2. Ship a baseline.
3. Iterate with evidence.
4. Document tradeoffs.
5. Demonstrate failures and fixes.
6. Treat safety as a core feature.

The expected evolution is:

```text
Baseline
  -> LLM
  -> Retrieval
  -> Tools
  -> Memory and Planning
  -> Adaptation
  -> Deployment
  -> Evaluation
```

The project should prioritize engineering judgment, reliability, explainability, safety-first design, and practical usefulness rather than unnecessary complexity or academic novelty.

## 10. Architecture Diagrams

PlantUML source files and rendered PNG diagrams are available in the `diagrams` directory:

| Diagram | Purpose |
| --- | --- |
| `01_high_level_architecture` | Overall LangChain agent architecture and system integrations |
| `02-phase-evolution` | Connection between Phases 1-9 and their inputs and outputs |
| `03-request-safety-flow` | Safety checks, refusal behavior, uncertainty, and human escalation |
| `04_retrieval_tools_simple` | Document retrieval and read-only tool processing |
| `05-memory-feedback-adaptation` | Planning, memory, feedback storage, and adaptive behavior |
| `06-deployment-and-evaluation` | Packaging, deployment, observability, and evaluation |

Each diagram has both a `.puml` source file and a rendered `.png` file.

---

## 11. How the Nine Phases Connect at Runtime

### 11.1 The core idea

The nine phases are **not nine separate programs**. They are nine layers of one request pipeline, built in the order that lets each layer be measured against the one before it.

The **Phase 8 service (`Solution/phase8/service.py`) is the spine**. It owns the request, the safety gate, the timing, and the logging. Every other phase is a component that plugs into that spine.

### 11.2 The live request path

A single user question flows through the layers in this order:

```text
        User question ("Why is shipment SHP-1024 delayed?")
                          |
                          v
+---------------------------------------------------------------+
| PHASE 8 - Service spine (service.py)                           |
|   - validates input, rejects empty/oversized requests          |
|   - starts the latency timer                                   |
|   - SafeEventLogger writes metadata only (no business content) |
+---------------------------------------------------------------+
                          |
                          v
+---------------------------------------------------------------+
| PHASE 6 - Planning and memory (planning_memory.py)             |
|   - builds a 4-step plan: classify -> identify -> evidence     |
|     -> respond                                                 |
|   - ShortTermMemory resolves follow-ups ("Why is IT delayed?"  |
|     -> SHP-1024)                                               |
+---------------------------------------------------------------+
                          |
                          v
+---------------------------------------------------------------+
| PHASE 4 - Retrieval (retrieval_agent.py)                       |
|   - embeds the question, searches the vector store             |
|   - scores hits against a relevance threshold                  |
|   - below threshold => "insufficient evidence", no guessing    |
+---------------------------------------------------------------+
                          |
                          v
+---------------------------------------------------------------+
| PHASE 5 - Read-only tools (tool_copilot.py)                    |
|   - search_inventory / get_shipment_status /                   |
|     get_supplier_metrics / search_business_documents           |
|   - typed schemas, loop prevention, tool-failure handling      |
|   - REFUSES update / delete / order / notify requests          |
+---------------------------------------------------------------+
                          |
                          v
+---------------------------------------------------------------+
| PHASE 3 - LLM answer (llm_agent.py)                            |
|   - ChatTogether via TOGETHER_API_KEY                          |
|   - safety_focused prompt is the production default            |
|   - SafeLLMLogger records hashes and lengths, never content    |
+---------------------------------------------------------------+
                          |
                          v
+---------------------------------------------------------------+
| PHASE 7 - Adaptation (feedback_adaptation.py)                  |
|   - applies the stored policy (e.g. "evidence_first")          |
|   - captures helpful / not-helpful feedback for next time      |
+---------------------------------------------------------------+
                          |
                          v
     Answer / Evidence / Uncertainty / Human next step
```

### 11.3 The phases that do not sit on the request path

Three phases are **supporting infrastructure**, not runtime layers:

| Phase | Role in the bigger solution |
| --- | --- |
| **Phase 1** | The **contract**. `phase1/test-scenarios.yaml` (Q01-Q10) is the single fixed test set reused by Phase 3 prompt comparison and Phase 9 evaluation. Change the contract, and every downstream measurement changes with it. |
| **Phase 2** | The **control arm**. The rule-based baseline is what Phase 9 compares against, so "the LLM improved things" becomes a measured claim instead of an opinion. |
| **Phase 9** | The **referee**. `evaluation_harness.py` replays the Phase 1 scenarios through the assembled pipeline and produces the metrics table. It runs offline, so it can gate every change in CI without spending API credits. |

### 11.4 Why this wiring works in production

- **One safety gate, not seven.** The refusal rule lives in the Phase 8 spine and is re-asserted in the Phase 5 tool layer. A new tool cannot accidentally become write-capable.
- **Swappable components.** Phases 3-7 are injected into the spine through constructors and Python `Protocol` interfaces (`ChatClient`, `AnswerGenerator`, `EmbeddingModel`). That is why every phase has an `--offline` or `build_offline_agent()` variant: the same pipeline runs with or without an API key.
- **One trace, two loggers.** `SafeLLMLogger` and `SafeEventLogger` both write metadata-only JSONL (SHA-256 hashes, lengths, categories, latency). No business content ever reaches disk.
- **Evidence flows forward, never backward.** Retrieval output becomes LLM input; LLM output becomes evaluation input. Nothing later can silently overwrite an earlier safety decision.

### 11.5 Assembly order for a real deployment

```text
1. Start the Phase 8 service.
2. Inject Phase 6 memory  -> gives the service multi-turn context.
3. Inject Phase 4 retriever -> gives the service grounded evidence.
4. Inject Phase 5 tools     -> gives the service live read-only lookups.
5. Inject Phase 3 client    -> gives the service natural-language answers.
6. Inject Phase 7 store     -> gives the service learned preferences.
7. Point Phase 9 at the assembled service -> gives you the scorecard.
```

Phases 1 and 2 are already "done" at this point: they defined the target and the baseline.

### 11.6 Where each piece lives

| Folder | Key file | Role in the assembled system |
| --- | --- | --- |
| `Solution/phase1` | `test-scenarios.yaml` | The shared Q01-Q10 contract |
| `Solution/phase2` | `baseline_agent.py` | Rule-based control arm |
| `Solution/phase3` | `llm_agent.py` | `ChatTogether` client, prompt variants, `SafeLLMLogger` |
| `Solution/phase4` | `retrieval_agent.py` | Embeddings, vector search, grounded answers |
| `Solution/phase5` | `tool_copilot.py` | Typed read-only tools and refusal logic |
| `Solution/phase6` | `planning_memory.py` | Plan decomposition and `ShortTermMemory` |
| `Solution/phase7` | `feedback_adaptation.py` | Feedback store and response-policy adapter |
| `Solution/phase8` | `service.py` | The runtime spine, safety gate, metrics, `SafeEventLogger` |
| `Solution/phase9` | `evaluation_harness.py` | Scoring, root-cause analysis, safety review |

---

## 12. Step-by-Step Execution Guide (For Anyone)

This section assumes **zero prior experience**. Follow it top to bottom. Every command is copy-paste ready for **Windows PowerShell**.

### Step 0: What you need before you start

| Requirement | How to check | If missing |
| --- | --- | --- |
| Windows PC | — | — |
| Python 3.10 or newer | Run `py -3 -V` in PowerShell | Install from [python.org/downloads](https://www.python.org/downloads/). Tick **"Add Python to PATH"** during install. |
| This project folder | Run `dir` inside it and look for `Solution` | Copy the project folder to your machine. |
| Together AI key (optional) | See Step 5 | Only needed for the two live-LLM runs. Everything else runs offline. |

> **You can complete and validate the entire project offline, with no API key and no internet.** The key is only needed to produce live-model evidence for Phases 3 and 4.

### Step 1: Open PowerShell in the project folder

1. Press the **Windows key**, type `PowerShell`, press **Enter**.
2. Type this and press Enter (adjust the path if you saved the project elsewhere):

```powershell
cd z:\Personal\CapstoneProject
```

3. Confirm you are in the right place:

```powershell
dir
```

You should see `README.md`, `Question`, `Solution`, and `diagrams`.

### Step 2: Confirm Python works

```powershell
py -3 -V
```

Expected output: something like `Python 3.14.5`. If you see an error, reinstall Python with **"Add Python to PATH"** ticked and reopen PowerShell.

### Step 3: Create a private workspace for the project (recommended)

This keeps project packages separate from the rest of your computer.

```powershell
cd z:\Personal\CapstoneProject
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
```

Your prompt now starts with `(.venv)`. If PowerShell blocks the activation script, run this once and try again:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

> **Skipping this step is fine.** If you skip it, just replace `python` with `py -3` in every command below.

### Step 4: Install the dependencies

Only Phases 3 and 4 need packages. Everything else is standard library.

```powershell
cd z:\Personal\CapstoneProject\Solution\phase3
py -m pip install -r requirements.txt
```

This installs `langchain-core` and `langchain-together`. Phase 4 uses the same two packages, so you do not need to install twice.

### Step 5: Set your Together AI key (optional, for live-model runs)

1. Create a free account at [together.ai](https://api.together.xyz/) and copy your API key.
2. Paste it into PowerShell **in the same window you will run commands from**:

```powershell
$env:TOGETHER_API_KEY = "paste-your-key-here"
$env:TOGETHER_MODEL   = "meta-llama/Llama-3.3-70B-Instruct-Turbo"
```

3. Confirm it is set without printing the secret:

```powershell
if ($env:TOGETHER_API_KEY) { "Key is set" } else { "Key is NOT set" }
```

**Safety rules — these are graded:**
- Never type the key into a source file, notebook, README, or screenshot.
- The variable disappears when you close PowerShell. That is intentional and correct.
- If you ever paste a key somewhere public, rotate it on the Together dashboard immediately.

### Step 6: Run every phase, in order

Run each block, read the "What you should see" line, and take a screenshot of the output.

---

#### Phase 1 — Problem framing (nothing to run)

Phase 1 is documentation. Open and read these four files:

```powershell
cd z:\Personal\CapstoneProject\Solution\phase1
dir
```

| File | What it proves |
| --- | --- |
| `problem-framing.md` | The user, workflow, boundaries, and assumptions |
| `success-criteria.md` | The measurable targets |
| `test-scenarios.yaml` | The fixed 10-question test set (Q01-Q10) used by Phases 3 and 9 |
| `workflow.png` | The workflow diagram |

**Validate:** open `test-scenarios.yaml` and confirm it contains Q01 through Q10 with an `expected_behavior` for each.

---

#### Phase 2 — Baseline agent (no LLM)

```powershell
cd z:\Personal\CapstoneProject\Solution\phase2
py run_demo.py
```

**What you should see:** five question-and-answer pairs. The fourth one ("Update the reorder quantity... and place an order") must be **refused**.

**Validate:**

```powershell
py -m unittest -v
```
Expected: `Ran 5 tests ... OK`.

**Evidence produced:** `logs/interactions.jsonl` (metadata only — open it and confirm there is no business text inside).

---

#### Phase 3 — LLM integration and prompt comparison

First, the offline run (always works, no key):

```powershell
cd z:\Personal\CapstoneProject\Solution\phase3
python run_comparison.py --offline
```

Then the **live Together AI run** (needs Step 5):

```powershell
python run_comparison.py
```

**What you should see:** 30 lines (10 scenarios x 3 prompt variants), each marked `success`, then `Default prompt: safety_focused`.

> If you see `LLM invocation failed: Connection error`, your key is not set or you have no internet. Re-run Step 5 in the same window.

**Validate:**

```powershell
python -m unittest -v
```
Expected: `Ran 6 tests ... OK`.

**Evidence produced:**
- `outputs/prompt-comparison.md` — the required comparison table
- `outputs/prompt-comparison.json` — raw results
- `logs/llm_interactions.jsonl` — metadata-only log

Open `outputs/prompt-comparison.md` and confirm the `safety_focused` rows refuse the unsafe request (Q05).

---

#### Phase 4 — Knowledge and retrieval

```powershell
cd z:\Personal\CapstoneProject\Solution\phase4
python run_retrieval_demo.py --offline
```

With a Together key, run the live version:

```powershell
python run_retrieval_demo.py
```

**What you should see:** three questions, each printed twice — **Without retrieval** (refuses to answer) and **With retrieval** (answers and cites source IDs such as `SHP-REC-1024`). The third question about the weather forecast must report **missing evidence**, because no such document exists.

**Validate:**

```powershell
python -m unittest -v
```
Expected: `Ran 7 tests ... OK`.

**Evidence produced:** `outputs/retrieval-comparison.json` — the before-versus-after proof.

---

#### Phase 5 — Read-only tools

```powershell
cd z:\Personal\CapstoneProject\Solution\phase5
python run_demo.py
```

**What you should see:** JSON responses showing which tool was selected, at least one failed/unknown lookup handled cleanly, and a refusal for the write request (`"refused": true`).

**Validate:**

```powershell
python -m unittest -v
```
Expected: `Ran 6 tests ... OK`.

---

#### Phase 6 — Planning and memory

```powershell
cd z:\Personal\CapstoneProject\Solution\phase6
python run_demo.py
```

**What you should see:** a conversation where turn 1 asks about `SHP-1024` and turn 2 asks "Why is **it** delayed?" — the agent resolves "it" from memory. Each turn prints a `plan` with four steps and a growing `memory_size`.

**Validate:**

```powershell
python -m unittest -v
```
Expected: `Ran 5 tests ... OK`.

---

#### Phase 7 — Adaptive behaviour

```powershell
cd z:\Personal\CapstoneProject\Solution\phase7
python run_demo.py
```

**What you should see:** two lines. `Before feedback` uses the `balanced` style. `After feedback` switches to `evidence_first` and adds an explicit Evidence and Uncertainty section. That difference is your adaptation proof.

**Validate:**

```powershell
python -m unittest -v
```
Expected: `Ran 4 tests ... OK`.

---

#### Phase 8 — Deployment readiness

```powershell
cd z:\Personal\CapstoneProject\Solution\phase8
python run_local.py
```

**What you should see:**
- `Health: {'status': 'ok', 'mode': 'offline', 'writes_enabled': 'false'}`
- A normal answer, a **refused** write request, and an **empty input** handled with `error_code: empty_request` (this is your graceful-failure demo)
- A `Metrics:` line with request count, error rate, and average latency

**Validate:**

```powershell
python -m unittest -v
```
Expected: `Ran 5 tests ... OK`.

**Evidence produced:** `local-events.jsonl` — metadata-only operational log with latencies.

---

#### Phase 9 — Evaluation

```powershell
cd z:\Personal\CapstoneProject\Solution\phase9
python run_evaluation.py
```

**What you should see:**
```text
Scenarios: 10
Accuracy: 100.0%
Wrote ...\reports\evaluation-report.json
Wrote ...\reports\evaluation-report.md
```

**Validate:**

```powershell
python -m unittest -v
```
Expected: `Ran 3 tests ... OK`.

**Evidence produced:** `reports/evaluation-report.md` — your metrics table, root-cause analysis, safety review, and improvement roadmap.

---

### Step 7: Run every test in one go (final check)

Paste this whole block into PowerShell:

```powershell
$py = "py"
$base = "z:\Personal\CapstoneProject\Solution"
foreach ($p in 2..9) {
  Push-Location (Join-Path $base "phase$p")
  Write-Output "--- phase$p ---"
  & $py -3 -m unittest -q 2>&1 | Select-Object -Last 1
  Pop-Location
}
```

**Expected:** `OK` printed for all eight phases. Total: **41 tests**.

If any line says `FAILED`, re-run that phase on its own with `python -m unittest -v` to see which test broke.

### Step 8: Validate the five required demo interactions

The assignment requires five specific interactions. Here is exactly where each one is proven:

| # | Required interaction | Run this | Look for |
| --- | --- | --- | --- |
| 1 | Normal question answered using retrieval | `phase4\run_retrieval_demo.py --offline` | "Why is shipment SHP-1024 delayed?" answered **with** cited source IDs |
| 2 | Multi-step question using more than one tool | `phase5\run_demo.py` | More than one tool name in the tool-call trace |
| 3 | Question where information is missing | `phase4\run_retrieval_demo.py --offline` | The weather-forecast question returning insufficient evidence |
| 4 | Unsafe request to modify data, refused | `phase8\run_local.py` | `"category": "unsafe_action"` with the refusal message |
| 5 | Ambiguous question triggering escalation | `phase9\run_evaluation.py` | Scenario `Q06` classified as `ambiguous`; `Q08`/`Q09` escalate |

Screenshot each one. Those five screenshots are your demo script evidence.

### Step 9: Validate the ten Phase 1 test scenarios

The fixed test set drives the final score. `python run_evaluation.py` in Phase 9 checks all ten automatically:

| ID | Scenario type | Correct behaviour |
| --- | --- | --- |
| Q01 | Supported inventory | Answer with evidence and stated assumptions |
| Q02 | Supported shipment | Answer with evidence, disclose stale data |
| Q03 | Supported supplier | Compare metrics, cite the data date |
| Q04 | Missing information | State what evidence is missing |
| Q05 | **Unsafe action** | **Refuse and redirect to a human workflow** |
| Q06 | Ambiguous | Ask a clarifying question, do not guess |
| Q07 | Unknown entity | Report no matching record |
| Q08 | Conflicting sources | Surface the conflict, recommend human review |
| Q09 | Stale data | Explain the freshness limitation |
| Q10 | Tool failure | Report the failure, do not invent a status |

Open `Solution\phase9\reports\evaluation-report.md` after the run and confirm all ten rows show `True` in the **Pass** column.

### Step 10: Capture your evidence for submission

Collect these files. They are all generated by the commands above.

| Submission item | File or artifact |
| --- | --- |
| Working LangChain agent | `Solution\phase3\llm_agent.py`, `phase4\retrieval_agent.py`, `phase5\tool_copilot.py`, `phase8\service.py` |
| Problem framing document | `Solution\phase1\problem-framing.md` |
| Workflow diagram | `Solution\phase1\workflow.png` + `diagrams\*.png` |
| Demo script (5 interactions) | Your screenshots from Step 8 |
| Prompt comparison table | `Solution\phase3\outputs\prompt-comparison.md` |
| Retrieval before/after evidence | `Solution\phase4\outputs\retrieval-comparison.json` |
| Tool evidence and refusals | Terminal output of `phase5\run_demo.py` |
| Memory and planning evidence | Terminal output of `phase6\run_demo.py` |
| Adaptation evidence | Terminal output of `phase7\run_demo.py` |
| Deployment and latency logs | `Solution\phase8\local-events.jsonl` + `run_local.py` output |
| Evaluation report | `Solution\phase9\reports\evaluation-report.md` |
| Safety and ethics review | Safety section inside the evaluation report |
| Setup instructions | This Section 12 |

**Before you submit, run this secret check:**

```powershell
cd z:\Personal\CapstoneProject
$hits = Get-ChildItem -Recurse -File -ErrorAction SilentlyContinue -Include *.py,*.md,*.json,*.yaml,*.txt,*.toml |
  Select-String -Pattern 'TOGETHER_API_KEY\s*=\s*["''][A-Za-z0-9]{20,}', 'sk-[A-Za-z0-9]{20,}' |
  Select-Object Path, LineNumber, Line
if ($hits) { $hits } else { "No secrets found." }
```

**Expected result: `No secrets found.`** Anything else means a real key may be sitting in a file — delete it and rotate the key on the Together dashboard immediately.

### Step 11: Troubleshooting

| Symptom | Cause | Fix |
| --- | --- | --- |
| `python : The term 'python' is not recognized` | Python is not on PATH, or the venv is not active | Use `py -3` instead of `python`, or re-run Step 3 |
| `ModuleNotFoundError: langchain_together` | Dependencies not installed | Re-run Step 4 |
| `TOGETHER_API_KEY is not set` | Key missing in this window | Re-run Step 5 **in the same PowerShell window**, or add `--offline` |
| `LLM invocation failed: Connection error` | No internet, or an invalid/expired key | Check connectivity, verify the key on the Together dashboard, then re-run |
| `ModuleNotFoundError: baseline_agent` (or similar) | You ran the script from the wrong folder | `cd` into that phase folder first — each phase runs from its own directory |
| `Activate.ps1 cannot be loaded` | PowerShell execution policy | Run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` |
| Rate limit / 429 from Together | Free-tier throttling | Wait a minute and re-run, or use `--offline` |

### Step 12: The 15-minute version

Short on time? This sequence proves the whole project end to end:

```powershell
cd z:\Personal\CapstoneProject\Solution\phase2; py -3 run_demo.py
cd ..\phase3; py -3 run_comparison.py --offline
cd ..\phase4; py -3 run_retrieval_demo.py --offline
cd ..\phase5; py -3 run_demo.py
cd ..\phase6; py -3 run_demo.py
cd ..\phase7; py -3 run_demo.py
cd ..\phase8; py -3 run_local.py
cd ..\phase9; py -3 run_evaluation.py
```

Then open `Solution\phase9\reports\evaluation-report.md` for the final scorecard.

