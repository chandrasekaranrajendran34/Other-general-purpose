"""Run every capstone phase end to end from a single entry point.

Intended for Google Colab, but it also works from any shell:

    python run_all_phases.py --offline      # no API key needed
    python run_all_phases.py --live         # Phase 3/4 call Together AI
    python run_all_phases.py --live --skip-tests

Phase 1 is documentation and test design, so it is validated by listing its
artifacts rather than by executing code.
"""

from __future__ import annotations

import argparse
import sys
import traceback

import colab_setup as cs


def _banner(title: str) -> None:
    print("\n" + "=" * 72)
    print(title)
    print("=" * 72)


def phase1() -> None:
    root = cs.project_root()
    directory = cs.phase_dir(1)
    for item in sorted(directory.iterdir()):
        if item.is_file():
            print(f"  {item.relative_to(root).as_posix()}  ({item.stat().st_size} bytes)")
    scenarios = (directory / "test-scenarios.yaml").read_text(encoding="utf-8")
    print(f"\nScenario definitions: {scenarios.count('- id:')} entries")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--offline", action="store_true",
                      help="Run Phase 3 and Phase 4 without an API key (default).")
    mode.add_argument("--live", action="store_true",
                      help="Run Phase 3 and Phase 4 against Together AI.")
    parser.add_argument("--skip-tests", action="store_true",
                        help="Skip the per-phase unittest runs.")
    args = parser.parse_args()

    cs.bootstrap()
    live = args.live
    if live:
        cs.install_requirements()
        if not cs.configure_together(prompt_if_missing=False):
            print("No TOGETHER_API_KEY available; falling back to offline mode.")
            live = False

    llm_args: list[str] = [] if live else ["--offline"]
    suffix = "together" if live else "offline"

    failures: list[str] = []
    steps = [
        ("Phase 1 - Problem framing and test design", phase1),
        ("Phase 2 - Baseline rule-based agent",
         lambda: cs.run_phase(2, "run_demo.py", save_as="run_demo.output")),
        ("Phase 3 - Prompt comparison",
         lambda: cs.run_phase(3, "run_comparison.py", llm_args,
                              save_as=f"{suffix}-prompt-comparison.out")),
        ("Phase 4 - Retrieval grounding",
         lambda: cs.run_phase(4, "run_retrieval_demo.py", llm_args,
                              save_as=f"{suffix}-retrieval-demo.out")),
        ("Phase 5 - Read-only tool routing",
         lambda: cs.run_phase(5, "run_demo.py", save_as="run_demo.output")),
        ("Phase 6 - Planning and memory",
         lambda: cs.run_phase(6, "run_demo.py", save_as="run_demo.output")),
        ("Phase 7 - Feedback adaptation",
         lambda: cs.run_phase(7, "run_demo.py", save_as="run_demo.output")),
        ("Phase 8 - Deployment boundary",
         lambda: cs.run_phase(8, "run_local.py", save_as="run_local.output")),
        ("Phase 9 - Evaluation harness",
         lambda: cs.run_phase(9, "run_evaluation.py", save_as="run_evaluation.output")),
    ]

    for title, step in steps:
        _banner(title)
        try:
            step()
        except Exception:
            failures.append(title)
            traceback.print_exc()

    if not args.skip_tests:
        for phase in (2, 3, 4, 5, 6, 7, 8, 9):
            _banner(f"Phase {phase} - unit tests")
            try:
                cs.run_phase_tests(phase)
            except Exception:
                failures.append(f"Phase {phase} tests")
                traceback.print_exc()

    _banner("Summary")
    print(f"Mode: {'Together AI (live)' if live else 'offline deterministic'}")
    if failures:
        print("Failed steps:")
        for name in failures:
            print(f"  - {name}")
        return 1
    print("All phases completed successfully.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
