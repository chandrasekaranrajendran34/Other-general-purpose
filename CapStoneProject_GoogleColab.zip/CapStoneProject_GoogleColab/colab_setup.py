"""Google Colab bootstrap helpers for the Inventory Operations Copilot capstone.

This module exists only to make the Phase 1 - Phase 9 solution runnable from a
Google Colab notebook. It does not change any phase logic. It provides:

* project root discovery that works for Drive, git clone, or uploaded ZIP,
* dependency installation for the phases that call Together AI,
* Together AI credential loading from Colab Secrets or an interactive prompt,
* a helper that runs a phase script with the correct working directory and
  optionally captures the console output into ``<phase>/outputs``.

Typical Colab usage::

    import colab_setup as cs
    cs.bootstrap()
    cs.install_requirements()
    cs.configure_together()
    cs.run_phase(3, "run_comparison.py", ["--offline"],
                 save_as="offline-prompt-comparison.out")
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path
from typing import Iterable, Sequence

__all__ = [
    "DEFAULT_TOGETHER_MODEL",
    "DEFAULT_TOGETHER_BASE_URL",
    "PHASE_REQUIREMENTS",
    "bootstrap",
    "configure_together",
    "install_requirements",
    "is_colab",
    "phase_dir",
    "project_root",
    "run_phase",
    "run_phase_tests",
    "show_file",
    "zip_outputs",
]

DEFAULT_TOGETHER_MODEL = "meta-llama/Llama-3.3-70B-Instruct-Turbo"
DEFAULT_TOGETHER_BASE_URL = "https://api.together.xyz/v1"

# Only Phase 3 and Phase 4 can call a hosted model. Every other phase is
# standard library only, which is why the list below is intentionally short.
PHASE_REQUIREMENTS = ("langchain-core>=0.3,<2", "langchain-together>=0.3,<2")

_ROOT: Path | None = None

# Marker files that identify the capstone root regardless of how it was copied
# into the Colab runtime.
_ROOT_MARKERS = ("Solution/phase1/test-scenarios.yaml", "Solution/phase9")


def is_colab() -> bool:
    """Return True when the current interpreter is a Colab runtime."""

    return "google.colab" in sys.modules or bool(os.environ.get("COLAB_RELEASE_TAG"))


def _looks_like_root(candidate: Path) -> bool:
    return all((candidate / marker).exists() for marker in _ROOT_MARKERS)


def _candidate_roots(explicit: str | os.PathLike[str] | None) -> Iterable[Path]:
    # ``os.path.abspath`` is used instead of ``Path.resolve`` so that mapped
    # network drives are not rewritten into UNC paths, which some SMB shares
    # report inconsistently.
    def _absolute(value: str | os.PathLike[str]) -> Path:
        return Path(os.path.abspath(os.path.expanduser(str(value))))

    if explicit is not None:
        yield _absolute(explicit)
        return
    here = _absolute(__file__).parent
    yield here
    yield from here.parents
    cwd = _absolute(Path.cwd())
    yield cwd
    yield from cwd.parents
    for base in (Path("/content"), Path("/content/drive/MyDrive")):
        if not base.is_dir():
            continue
        yield base
        try:
            for child in sorted(base.iterdir()):
                if child.is_dir():
                    yield child
        except OSError:
            continue


def bootstrap(path: str | os.PathLike[str] | None = None, verbose: bool = True) -> Path:
    """Locate the capstone root, make it importable, and return it."""

    global _ROOT
    for candidate in _candidate_roots(path):
        if _looks_like_root(candidate):
            _ROOT = candidate
            break
    else:
        raise FileNotFoundError(
            "Could not find the capstone root. Expected a directory containing "
            "Solution/phase1 ... Solution/phase9. Pass the path explicitly, for "
            "example: colab_setup.bootstrap('/content/CapStoneProject_GoogleColab')"
        )

    if str(_ROOT) not in sys.path:
        sys.path.insert(0, str(_ROOT))
    os.chdir(_ROOT)
    if verbose:
        print(f"Project root : {_ROOT}")
        print(f"Python       : {sys.version.split()[0]}")
        print(f"Colab runtime: {is_colab()}")
    return _ROOT


def project_root() -> Path:
    """Return the bootstrapped project root, bootstrapping on first use."""

    return _ROOT if _ROOT is not None else bootstrap(verbose=False)


def phase_dir(phase: int | str) -> Path:
    """Return the directory for a phase number (1-9) or a phase folder name."""

    name = f"phase{phase}" if str(phase).isdigit() else str(phase)
    directory = project_root() / "Solution" / name
    if not directory.is_dir():
        raise FileNotFoundError(f"Phase directory not found: {directory}")
    return directory


def install_requirements(extra: Sequence[str] = (), quiet: bool = True) -> None:
    """Install the LangChain/Together packages used by Phase 3 and Phase 4."""

    packages = [*PHASE_REQUIREMENTS, *extra]
    command = [sys.executable, "-m", "pip", "install", *(["-q"] if quiet else []), *packages]
    print("Installing:", " ".join(packages))
    subprocess.run(command, check=True)
    print("Dependency installation complete.")


def _read_colab_secret(name: str) -> str | None:
    try:
        from google.colab import userdata  # type: ignore[import-not-found]
    except Exception:
        return None
    try:
        value = userdata.get(name)
    except Exception:
        return None
    return value.strip() if isinstance(value, str) and value.strip() else None


def configure_together(
    model: str = DEFAULT_TOGETHER_MODEL,
    base_url: str = DEFAULT_TOGETHER_BASE_URL,
    prompt_if_missing: bool = True,
) -> bool:
    """Populate the Together AI environment variables used by Phase 3 and 4.

    The key is read from the Colab Secrets panel (``TOGETHER_API_KEY``) when
    available, then from the existing environment, and finally from a hidden
    interactive prompt. Returns True when a key is available.
    """

    os.environ["TOGETHER_MODEL"] = model
    os.environ["TOGETHER_BASE_URL"] = base_url

    key = _read_colab_secret("TOGETHER_API_KEY") or os.environ.get("TOGETHER_API_KEY")
    if not key and prompt_if_missing:
        import getpass

        key = getpass.getpass("Together AI API key (input hidden): ").strip()

    if not key:
        os.environ.pop("TOGETHER_API_KEY", None)
        print("No Together AI key configured. Live phases must use --offline.")
        return False

    os.environ["TOGETHER_API_KEY"] = key
    print(f"TOGETHER_API_KEY configured (length {len(key)}).")
    print(f"TOGETHER_MODEL   = {model}")
    print(f"TOGETHER_BASE_URL= {base_url}")
    return True


def _ensure_dir(directory: Path) -> Path:
    """Create a directory, tolerating network shares that raise on re-create."""

    import time

    for attempt in range(5):
        try:
            directory.mkdir(parents=True, exist_ok=True)
            return directory
        except FileExistsError:
            # Some SMB/Drive-backed mounts briefly report a stale, non-directory
            # state for a path that already exists, so retry and then accept it.
            if os.path.isdir(directory):
                return directory
            if attempt == 4:
                if os.path.exists(directory):
                    return directory
                raise
            time.sleep(0.2)
    return directory


def _execute(command: Sequence[str], cwd: Path) -> tuple[str, int]:
    process = subprocess.run(
        command,
        cwd=str(cwd),
        env=os.environ.copy(),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    return process.stdout, process.returncode


def run_phase(
    phase: int | str,
    script: str,
    args: Sequence[str] = (),
    save_as: str | None = None,
    echo: bool = True,
) -> str:
    """Run ``script`` inside a phase directory and return its combined output.

    Running with ``cwd`` set to the phase directory keeps the original sibling
    imports (``from llm_agent import ...``) working unchanged.
    """

    directory = phase_dir(phase)
    target = directory / script
    if not target.is_file():
        raise FileNotFoundError(f"Script not found: {target}")

    output, code = _execute([sys.executable, script, *args], directory)
    if echo:
        print(output, end="" if output.endswith("\n") else "\n")
    if save_as:
        destination = directory / "outputs" / save_as
        _ensure_dir(destination.parent)
        destination.write_text(output, encoding="utf-8")
        print(f"Saved output -> {destination.relative_to(project_root())}")
    if code != 0:
        raise RuntimeError(f"{script} exited with status {code}")
    return output


def run_phase_tests(
    phase: int | str,
    save_as: str | None = "unittest.output",
    echo: bool = True,
) -> str:
    """Run ``python -m unittest -v`` for a phase and optionally save the log."""

    directory = phase_dir(phase)
    output, code = _execute([sys.executable, "-m", "unittest", "-v"], directory)
    if echo:
        print(output, end="" if output.endswith("\n") else "\n")
    if save_as:
        destination = directory / "outputs" / save_as
        _ensure_dir(destination.parent)
        destination.write_text(output, encoding="utf-8")
        print(f"Saved output -> {destination.relative_to(project_root())}")
    if code != 0:
        raise RuntimeError(f"Tests failed for {directory.name} (status {code})")
    return output


def show_file(relative_path: str, max_lines: int | None = 60) -> str:
    """Print (and return) a text file relative to the project root."""

    target = project_root() / relative_path
    text = target.read_text(encoding="utf-8")
    lines = text.splitlines()
    shown = lines if max_lines is None else lines[:max_lines]
    print("\n".join(shown))
    if max_lines is not None and len(lines) > max_lines:
        print(f"... [{len(lines) - max_lines} more lines in {relative_path}]")
    return text


def zip_outputs(archive_name: str = "capstone_outputs.zip") -> Path:
    """Bundle every generated output/report/log directory into one archive."""

    import zipfile

    root = project_root()
    archive = root / archive_name
    tracked = ("outputs", "logs", "reports")
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as bundle:
        for directory in sorted(root.glob("Solution/phase*/*")):
            if directory.is_dir() and directory.name in tracked:
                for item in sorted(directory.rglob("*")):
                    if item.is_file():
                        bundle.write(item, item.relative_to(root).as_posix())
        for stray in sorted(root.glob("Solution/phase*/*.jsonl")):
            bundle.write(stray, stray.relative_to(root).as_posix())
    print(f"Wrote {archive} ({archive.stat().st_size} bytes)")
    return archive
